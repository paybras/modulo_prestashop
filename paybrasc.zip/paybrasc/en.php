<?php
/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
global $_MODULE;
$_MODULE = array();

?>
