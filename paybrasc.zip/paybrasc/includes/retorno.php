﻿<?php

/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
#Descomente para testes
#@file_put_contents('retorno.txt', print_r($_POST, true));

include(dirname(__FILE__).'/../../../config/config.inc.php');


include(dirname(__FILE__).'/../paybrasc.php');


$retorno= json_decode($_POST['data']);


if ($retorno->recebedor_api_token==Configuration::get('PAYBRASC_TOKEN'))
{
		if($retorno->transacao_recuperada_id)
		{
			#é uma transação recuperada, seleciona e atualiza	
			$id_transacao 		= Db::getInstance()->getValue("SELECT 

id_order FROM "._DB_PREFIX_."orders WHERE id_transacao_paybras='".$retorno->transacao_id."' ");

			#atualiza com a id de transacao nova
			
			Db::getInstance()->ExecuteS("UPDATE "._DB_PREFIX_."orders SET id_transacao_paybras='".$retorno->transacao_id."' WHERE id_order=".$id_transacao);
			
			
		}
	    $id_transacao 		= Db::getInstance()->getValue("SELECT 

id_order FROM "._DB_PREFIX_."orders WHERE id_transacao_paybras='".$retorno->transacao_id."' ");



        $status_pagamento 	= $retorno->status_codigo;

        $order 				= new Order(intval($id_transacao));
        $cart 				= Cart::getCartByOrderId($id_transacao);

		switch($status_pagamento)
		{
			case 2: #Em Análise
				$status = Configuration::get('PAYBRASC_STATUS2');
			break;
			
			case 3: #Não Autorizado
				$status = Configuration::get('PAYBRASC_STATUS4');
			break;
			
			case 4: #aprovado
				$status = Configuration::get('PAYBRASC_STATUS3');
			break;

			case 5: #recusado
			$status = Configuration::get('PAYBRASC_STATUS5');
			break;
			
			case 6: #devolvido
				$status = Configuration::get('PAYBRASC_STATUS6');
			break;
			
			case 9: #chargeback em análise
				$status = Configuration::get('PAYBRASC_STATUS7');
			break;
		
		}


			
		
		$objOrder = new Order($id_transacao); //order with id=1
		$history = new OrderHistory();
		#$objOrder->setCurrentState($id_compra);
		$history->id_order = (int)$objOrder->id;
		$history->changeIdOrderState($status, (int)($objOrder->id)); 

		$history->addWithemail(true);
		
		
		$retorno['retorno'] = 'ok';
		echo json_encode($retorno);	
		
        
}

?>