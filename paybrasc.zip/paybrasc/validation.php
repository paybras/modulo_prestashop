<?php

/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
 
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');


function get_ip() {
    $keys = array(
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    );

    foreach ($keys as $key) {
        if (array_key_exists($key, $_SERVER)) {
            if (filter_var($_SERVER[$key], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
                return $_SERVER[$key];
            }
        }
    }
}


$currency = new Currency(intval(isset($_POST['currency_payement']) ? $_POST['currency_payement'] : $cookie->id_currency));
$total = (number_format($cart->getOrderTotal(true, 3), 2, '.', ''));

$paybrasc = new PaybrasC();

$mailVars 	= array
	(
		'{email}'			=> Configuration::get('PS_SHOP_EMAIL'),
		'{firstname}' 		=> stripslashes($customer->firstname), 
		'{lastname}' 		=> stripslashes($customer->lastname	),
		'{terceiro}'		=> stripslashes($paybrasc->displayName),
		'{id_order}'		=> $order->id,
		'{status}'			=> Configuration::get('PAYBRASC_STATUS1'),
		'{link}'			=> $paybrasc->getUrlByMyOrder($order)
	);

	
	$paybrasc->validateOrder
	(
		$cart->id, 
		Configuration::get('PAYBRASC_STATUS1'), 
		$total, 
		$paybrasc->displayName, 
		NULL, 
		$mailVars, 
		$currency->id
	);
	
	
$order 		= new Order($paybrasc->currentOrder);
	$idCustomer = $order->id_customer;
	$idLang		= $order->id_lang;
	$customer 	= new Customer(intval($idCustomer));
	$CusMail	= $customer->email;
	
	
	$id_compra=$order->id;

	$order_products = $order->getProducts();

/*

	Seleciona o endereço da fatura para enviar
	ao gateway da Paybrás Mais informações sobre o assunto adiante

*/
	$conexao=@mysql_connect(_DB_SERVER_, _DB_USER_, _DB_PASSWD_);
    $query_state = mysql_query('
        SELECT `iso_code`
        FROM `'._DB_PREFIX_.'state` s
        left join `'._DB_PREFIX_.'address` a
            on s.`id_state` = a.`id_state`
        WHERE a.`id_address`='.$cart->id_address_invoice.'', $conexao);

	$conexao=@mysql_connect(_DB_SERVER_, _DB_USER_, _DB_PASSWD_);
    mysql_select_db( _DB_NAME_, $conexao);

    $query_endereco = mysql_query('
        SELECT a.`id_state`, a.`id_customer`, a.`firstname` nome, a.`lastname` sobrenome, 
        a.`address1` endereco, a.`address2` complemento, a.`postcode` cep, a.`city` cidade, c.`email`, a.`phone`, a.`phone_mobile` 
        FROM `'._DB_PREFIX_.'address` a, `'._DB_PREFIX_.'customer` c
        WHERE a.`id_address`='.$cart->id_address_delivery.' AND c.`id_customer`=a.`id_customer` LIMIT 1', $conexao);

	$endereco = mysql_fetch_object($query_endereco);		
    $estado = @mysql_fetch_object($query_state);

	$endereco->celular=substr(preg_replace("/[^0-9]/","",$endereco->phone_mobile), 0, 11);
	$endereco->telefone=substr(preg_replace("/[^0-9]/","",$endereco->phone), 0, 11);

	$ddd_telefone = $_POST['cartao_telefone_ddd'] . $_POST['cartao_telefone'];
    $telefone_cartao = substr(preg_replace("/[^0-9]/", "", $ddd_telefone), 0, 11);


if(!$estado)
{


    $query_state = mysql_query('
        SELECT `iso_code`
        FROM `'._DB_PREFIX_.'state` s
        left join `'._DB_PREFIX_.'address` a
            on s.`id_state` = a.`id_state`
        WHERE a.`id_address`='.$cart->id_address_invoice.'', $conexao);

  $query_endereco = mysql_query('
        SELECT a.`id_state`, a.`id_customer`, a.`firstname` nome, a.`lastname` sobrenome, 
        a.`address1` endereco, a.`address2` complemento, a.`postcode` cep, a.`city` cidade, c.`email`, a.`phone`, a.`phone_mobile` 
        FROM `'._DB_PREFIX_.'address` a, `'._DB_PREFIX_.'customer` c
        WHERE a.`id_address`='.$cart->id_address_invoice.' AND c.`id_customer`=a.`id_customer` LIMIT 1', $conexao);

	$endereco = mysql_fetch_object($query_endereco);		
    $estado = mysql_fetch_object($query_state);

	$endereco->celular=substr(preg_replace("/[^0-9]/","",$endereco->phone_mobile), 0, 11);
	$endereco->telefone=substr(preg_replace("/[^0-9]/","",$endereco->phone), 0, 11);

	$ddd_telefone = $_POST['cartao_telefone_ddd'] . $_POST['cartao_telefone'];
    $telefone_cartao = substr(preg_replace("/[^0-9]/", "", $ddd_telefone), 0, 11);


}

	
	if(Configuration::get('PS_SSL_ENABLED'))
		$url_retorno=_PS_BASE_URL_SSL_.__PS_BASE_URI__."modules/paybrasc/includes/retorno.php";
	else
		$url_retorno=_PS_BASE_URL_.__PS_BASE_URI__."modules/paybrasc/includes/retorno.php";
	
	
	
	$dados['recebedor_api_token'] = Configuration::get('PAYBRASC_TOKEN');
	$dados['recebedor_email'] = Configuration::get('PAYBRASC_EMAIL');
	$dados['pedido_id'] = $id_compra;
	$dados['pedido_descricao'] = 'Pedido '.$id_compra.' efetuado em '._PS_BASE_URL_.__PS_BASE_URI__;
	$dados['pedido_meio_pagamento'] = 'cartao';
	$dados['pedido_moeda'] = 'BRL';
	$dados['pedido_valor_total_original'] = $cart->getOrderTotal(true);
	$dados['pagador_nome'] = $_POST['fatura_nome'];
	$dados['pagador_email'] = $endereco->email;
	$dados['pagador_cpf'] = $_POST['cartao_cpf'];
	$dados['pagador_rg'] = '';
	$dados['pagador_telefone_ddd'] = $_POST['cartao_telefone_ddd'];
	$dados['pagador_telefone'] = $_POST['cartao_telefone'];
	$dados['pagador_celular_ddd'] = $_POST['cartao_telefone_ddd'];
	$dados['pagador_celular'] = $_POST['cartao_telefone'];
	#$dados['pagador_sexo'] = '';
	#$dados['pagador_data_nascimento'] = '05/02/1988';
	$dados['pagador_ip'] = get_ip();
	$dados['pagador_logradouro'] = $_POST['fatura_endereco'];
	$dados['pagador_numero'] = $_POST['fatura_numero'];
	$dados['pagador_complemento'] = $_POST['fatura_bairro'];
	$dados['pagador_bairro'] =$_POST['fatura_bairro'];
	$dados['pagador_cep'] =  $_POST['fatura_cep'];
	$dados['pagador_cidade'] = $_POST['fatura_cidade'] ;
	$dados['pagador_estado'] = $_POST['fatura_estado'];
	
	$dados['pagador_pais'] = 'BRA';
	$dados['entrega_nome'] =$_POST['fatura_nome'];
	$dados['entrega_estado'] = $_POST['fatura_estado'];
	$dados['entrega_pais'] = 'BRA';
	$dados['entrega_logradouro'] = $_POST['fatura_endereco'];
	$dados['entrega_numero'] = $_POST['fatura_numero'];
	$dados['entrega_complemento'] = $_POST['fatura_bairro'];
	$dados['entrega_bairro'] = $_POST['fatura_bairro'];
	$dados['entrega_cep'] = $_POST['fatura_cep'];
	$dados['entrega_cidade'] = $_POST['fatura_cidade'] ;
	
	$dados['cartao_numero']=$_POST['cartao_numero1'];
	$dados['cartao_parcelas']=$_POST['parcelas'];
	$dados['cartao_codigo_de_seguranca']=$_POST['cartao_codigo'];
	$dados['cartao_bandeira']=$_POST['bandeira_cartao'];
	$dados['cartao_portador_nome']=$_POST['cartao_titular'];
	$dados['cartao_validade_mes']=$_POST['cartao_mes'];
	$dados['cartao_validade_ano']=$_POST['cartao_ano'];
	$dados['cartao_portador_cpf']=$_POST['cartao_cpf'];
	#$dados['cartao_portador_data_de_nascimento']=$_POST['data_nascimento'];
	$dados['cartao_portador_telefone_ddd']=$_POST['cartao_telefone_ddd'];
	$dados['cartao_portador_telefone']=$_POST['cartao_telefone'];
	
	foreach($order_products as $order_product) 
	{
		$object = new stdClass();
		$produto =  array('produto_codigo'=>$order_product['product_id'], 'produto_nome'=>$order_product['product_name'],'produto_categoria'=>'','produto_valor'=>number_format($order_product['unit_price_tax_incl'], 2, '.', ''),'produto_qtd'=>$order_product['product_quantity'],'produto_peso'=>0);
		
		foreach ($produto as $key => $value)
		{
			$object->$key = $value;
		}
		$dados['produtos'][] = $object;
	}
	
	$data_string=json_encode($dados);
	
	$url='https://service.paybras.com/payment/api/criaTransacao';
	
	$ch = curl_init();

        
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
        );

$resultado=(json_decode((curl_exec($ch))));

#Descomentar para depuração
#file_put_contents('teste.txt', print_r($resultado, true).' - ' . print_r(data_string, true));

	/*
		De acordo com  o retorno do PAYBRAS, define a mensagem
		que aparecerá na página final do pagamento.
	
	*/
if(!strpos($_POST['fatura_endereco'], $_POST['fatura_numero']))
$novo_endereco=$_POST['fatura_endereco'].' '.$_POST['fatura_numero'];
else $novo_endereco=$_POST['fatura_endereco'];

$query_endereco = mysql_query('UPDATE `'._DB_PREFIX_.'address` set address1="'.$novo_endereco.'"id_address='.$cart->id_address_delivery.' AND c.`id_customer`=a.`id_customer` LIMIT 1', $conexao);
    $status = $resultado->status_codigo;    
    $transacao = $resultado->transacao_id; 
	$codigo_nao_autorizado=0;

	if($resultado->sucesso==1)
	{
		switch($status)
		{
			case 2:
			$fim_url='&res=2';
			$novo_status=(Configuration::get('PAYBRASC_STATUS2'));
			break;
			case 3:
			$fim_url='&res=3&codigo='.$resultado->nao_autorizado_codigo;
			$codigo_nao_autorizado=$resultado->nao_autorizado_codigo;
			$novo_status=(Configuration::get('PAYBRASC_STATUS4'));
			break;
			case 4:
			$novo_status=(Configuration::get('PAYBRASC_STATUS3'));
			$fim_url='&res=4';
			break;
			
		}
		
	}
	else
	{
		$novo_status=(Configuration::get('PAYBRASC_STATUS8'));
		$fim_url='&res=8&';
	}
	
		
		
		$objOrder = new Order($id_compra); 
		$history = new OrderHistory();
		#$objOrder->setCurrentState($id_compra);
		$history->id_order = (int)$objOrder->id;
		$history->changeIdOrderState($novo_status, (int)($objOrder->id)); //order status=3
		$history->addWithemail(true);
		
		$cartao=$dados['cartao_numero'];
		$bin=str_pad(substr($cartao,0,4), strlen($cartao)-4,'.').substr($cartao,strlen($cartao)-4,4);
		
		 Db::getInstance()->Execute("INSERT INTO "._DB_PREFIX_."transacoes_paybras (id_order,meio_pagamento,ip,nome,bandeira,bin,telefone,cpf,id_transacao,parcelas, codigo_nao_autorizado) 
		 VALUES (".$id_compra.", 'c','".$_SERVER['REMOTE_ADDR']."', '".$_POST['cartao_titular']."', '".$_POST['bandeira_cartao']."', 
		 '".$bin."', '".$_POST['cartao_telefone_ddd']."-".$_POST['cartao_telefone']."','".$_POST['cartao_cpf']."',
		  ". $transacao.", 
		  ".$_POST['parcelas'].", ".$codigo_nao_autorizado.")");
		 
		 Db::getInstance()->Execute("UPDATE "._DB_PREFIX_."orders SET id_transacao_paybras='".$transacao."' WHERE id_order=".$id_compra." LIMIT 1");
		

Tools::redirectLink(__PS_BASE_URI__.'order-confirmation.php?id_cart='.$cart->id.'&id_module='.$paybrasc->id.'&id_order='.$paybrasc->currentOrder.'&key='.$order->secure_key.$fim_url);

?>