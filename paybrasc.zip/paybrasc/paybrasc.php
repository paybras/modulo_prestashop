<?php

/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
class PaybrasC extends PaymentModule
{
	private $_html 			= '';
    private $_postErrors 	= array();
    public $currencies;
	private $status;
		
	public function __construct()
    {
        $this->name 			= 'paybrasc';
        $this->tab 				= 'payments_gateways';
        $this->version 			= '1.0';

        $this->currencies 		= true;
        $this->currencies_mode 	= 'radio';
	
		
        parent::__construct();

        $this->page 			= basename(__file__, '.php');
        $this->displayName 		= $this->l('Paybrás - Cartões de Crédito');
		$this->author			= "www.consultoriadaweb.com.br";
        $this->description 		= $this->l('Permite receber pagamentos com cartão de crédito através do gateway Paybrás');
		$this->confirmUninstall = $this->l('Tem certeza de que pretende eliminar os seus dados?');
		$this->textshowemail 	= $this->l('Você receberá por mensagens por e-mail informando a cadaatualização da sua compra.');
	}
	
	public function install()
	{
		
        $this->criar_tabela_transacoes();

		if(!$email=Configuration::get('PAYBRASC_EMAIL'))
			$email='paybras@seudominio.com.br';
		
			
		if(!$token=Configuration::get('PAYBRASC_TOKEN'))
			$token='';

		if 
		(
			!parent::install() 
			|| !$this->registerHook('displayHeader') 
		OR 	!Configuration::updateValue('PAYBRASC_EMAIL', $email)
		OR 	!Configuration::updateValue('PAYBRASC_TOKEN', 	  $contaid)
		OR 	!Configuration::updateValue('PAYBRASC_BTN', 	  0)  
		OR 	!Configuration::updateValue('PAYBRASC_MENSAGEM_EM_ANALISE',   'Seu pagamento encontra-se <span class="price">Em Análise</span> pela operadora do seu cartão de crédito. Você receberá um e-mail automático informando quando o mesmo for aprovado.')    
		OR 	!Configuration::updateValue('PAYBRASC_MENSAGEM_CANCELADO',   'Seu pagamento <span class="price">não</span> foi autorizado pela operadora do seu cartão. Você pode ter digitado dados errados ou a operação ultrapassa o limite disponível no seu cartão. Por favor, efetue um novo pedido e corrija seus dados. Se necessário, você também poderá escolher outra forma de pagamento.') 
		OR 	!Configuration::updateValue('PAYBRASC_MENSAGEM_APROVADO',   'Seu pagamento já foi <span class="price">aprovado</span> por sua operadora de cartão e em breve seu pedido começará a ser processado.')    

		OR 	!$this->registerHook('payment') 
		OR 	!$this->registerHook('paymentReturn')
		 OR !$this->registerHook('adminOrder')
		 OR 	!$this->registerHook('header') 
		)
			return false;
			
		return true;
	}

		private function getCombo($nome, $opcoes, $selecionado=false)
	{
		$combo='<select name="'.$nome.'" id="'.$nome.'">';
		
		foreach($opcoes as $i=> $valor)
		{
			if($i!=$selecionado)
				$combo .='<option value="'.$i.'" >'.$valor.'</option>>';
			else
				$combo .='<option value="'.$i.'" selected="selected">'.$valor.'</option>>';
			
		}
		
		$combo .="</select>";
		
		return ($combo);
		
	}


    public function criar_tabela_transacoes()
    {
		try {
    
			@Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'orders` ADD `id_transacao_paybras` VARCHAR(36) NULL ;');
			
			} catch (Exception $e) {}

		try {
    
			@Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'transacoes_paybras` (
			  `id_order` int(11) NOT NULL,
			  `meio_pagamento` char(1) NOT NULL,
			  `ip` varchar(15) NOT NULL,
			  `nome` varchar(30) NOT NULL,
			  `bandeira` varchar(20) NOT NULL,
			  `bin` varchar(20) NOT NULL,
			  `telefone` varchar(15) NOT NULL,
			  `cpf` varchar(14) NOT NULL,
			  `id_transacao` int(11) NOT NULL,
			  `codigo_nao_autorizado` int(11) NOT NULL,
			  `recuperada` int(11) NOT NULL,
			  `parcelas` int(11) NOT NULL,
			  PRIMARY KEY (`id_order`)
			) ;
			');
		} catch (Exception $e) { }
    }

	public function uninstall()
	{
		
		if 
		(
		
		!parent::uninstall()
		) 
			return false;
		
		return true;
	}

	public function getContent()
	{
		/*
			Essa função é responsável por salvar os dados da configuração
		*/
		$this->_html = '<h2>Paybrás- Cartões de Crédito</h2>';
		
		if (isset($_POST['submitPaybras']))
		{
			if (empty($_POST['paybras_email'])) $this->_postErrors[] = $this->l('E-mail da conta Paybrás');
			elseif (!Validate::isEmail($_POST['paybras_email'])) $this->_postErrors[] = $this->l('Digite um e-mail válido!');
			
				if (!sizeof($this->_postErrors)) 
				{
						Configuration::updateValue('PAYBRASC_EMAIL', $_POST['paybras_email']);
						
						if (!empty($_POST['paybras_token']))
						{
							Configuration::updateValue('PAYBRASC_TOKEN', trim($_POST['paybras_token']));
						}
						
						
						if (!empty($_POST['paybras_mensagem_em_analise']))
						{
							Configuration::updateValue('PAYBRASC_MENSAGEM_EM_ANALISE', $_POST['paybras_mensagem_em_analise']);
						}
						
						if (!empty($_POST['paybras_mensagem_aprovado']))
						{
							Configuration::updateValue('PAYBRASC_MENSAGEM_APROVADO', $_POST['paybras_mensagem_aprovado']);
						}
						
						if (!empty($_POST['paybras_mensagem_cancelado']))
						{
							Configuration::updateValue('PAYBRASC_MENSAGEM_CANCELADO', $_POST['paybras_mensagem_cancelado']);
						}
						if (!empty($_POST['paybras_status1']))
						{
							Configuration::updateValue('PAYBRASC_STATUS1', $_POST['paybras_status1']);
						}
						if (!empty($_POST['paybras_status2']))
						{
							Configuration::updateValue('PAYBRASC_STATUS2', $_POST['paybras_status2']);
						}
						if (!empty($_POST['paybras_status3']))
						{
							Configuration::updateValue('PAYBRASC_STATUS3', $_POST['paybras_status3']);
						}
						
						if (!empty($_POST['paybras_status4']))
						{
							Configuration::updateValue('PAYBRASC_STATUS4', $_POST['paybras_status4']);
						}
						if (!empty($_POST['paybras_status5']))
						{
							Configuration::updateValue('PAYBRASC_STATUS5', $_POST['paybras_status5']);
						}
						if (!empty($_POST['paybras_status6']))
						{
							Configuration::updateValue('PAYBRASC_STATUS6', $_POST['paybras_status6']);
						}
						if (!empty($_POST['paybras_status7']))
						{
							Configuration::updateValue('PAYBRASC_STATUS7', $_POST['paybras_status7']);
						}
						if (!empty($_POST['paybras_status8']))
						{
							Configuration::updateValue('PAYBRASC_STATUS8', $_POST['paybras_status8']);
						}
						if (!empty($_POST['paybras_template']))
						{
							Configuration::updateValue('PAYBRASC_TEMPLATE', $_POST['paybras_template']);
						}
						
					$this->displayConf();
				}
				else $this->displayErrors();
		}
		elseif (isset($_POST['submitpaybras_Btn']))
		{
			Configuration::updateValue('PAYBRASC_BTN', 	$_POST['btn_pg']);
			$this->displayConf();
		}
		

		$this->displayPaybrasC();
		$this->displayFormSettingsPaybrasC();
		
		return $this->_html;
	}
	
	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirm').'" />
			'.$this->l('Configurações do módulo atualizadas com sucesso!').'
		</div>';
	}
	
	public function displayErrors()
	{
		$nbErrors = sizeof($this->_postErrors);
		$this->_html .= '
		<div class="alert error">
			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
			<ol>';
		foreach ($this->_postErrors AS $error)
			$this->_html .= '<li>'.$error.'</li>';
		$this->_html .= '
			</ol>
		</div>';
	}

	public function displayPaybrasC()
	{
		$this->_html .= '
		<img src="../modules/paybrasc/img/paybrasc.jpg" style="float:left; margin-right:15px;" />
		<b>'.$this->l('Este módulo permite aceitar pagamentos via Paybrás com Cartões de Crédito.').'</b><br /><br />
		'.$this->l('Se o cliente escolher o módulo de pagamento, a conta da Paybrás será automaticamente creditada.').'<br />
		'.$this->l('É obrigatório que todas as configurações sejam preenchidas para que o módulo funcione adequadamente.').'
		<br /><br /><br />';
	}
	
	private function setStatus()
	{
		global $cookie;
		$id_lang = $cookie->id_lang;

		$sql="SELECT name, id_order_state FROM "._DB_PREFIX_."order_state_lang WHERE id_lang=".$id_lang."";
		
		
		$this->status=Db::getInstance()->ExecuteS($sql);
	}
	
	private function getComboStatus($nome, $selecionado=false)
	{
		if(!$this->status)
		{
			
			$this->setStatus();
			
		}
		$combo='<select name="'.$nome.'" id="'.$nome.'">';
		
		for($i=0; $i < count($this->status); $i++)
		{
			if($this->status[$i]['id_order_state']!=$selecionado)
				$combo .='<option value="'.$this->status[$i]['id_order_state'].'" >'.$this->status[$i]['name'].'</option>>';
			else
				$combo .='<option value="'.$this->status[$i]['id_order_state'].'" selected="selected">'.$this->status[$i]['name'].'</option>>';
			
		}
		
		$combo .="</select>";
		
		
		return ($combo);
		
		
	}

	public function displayFormSettingsPaybrasC()
	{
		$conf = Configuration::getMultiple
		(array(
			'PAYBRASC_EMAIL',
			'PAYBRASC_TOKEN',
			'PAYBRASC_MENSAGEM_CANCELADO',
			'PAYBRASC_MENSAGEM_EM_ANALISE',
			'PAYBRASC_MENSAGEM_APROVADO',
			'PAYBRASC_STATUS1',
			'PAYBRASC_STATUS2',
			'PAYBRASC_STATUS3',
			'PAYBRASC_STATUS4',
			'PAYBRASC_STATUS5',
			'PAYBRASC_STATUS6',
			'PAYBRASC_STATUS7',
			'PAYBRASC_STATUS8',
			'PAYBRASC_TEMPLATE'
			
			  )
		);
		
		$email	= array_key_exists('paybras_email', $_POST) ? $_POST['paybras_email'] : (array_key_exists('PAYBRASC_EMAIL', $conf) ? $conf['PAYBRASC_EMAIL'] : '');
		
		$token		= array_key_exists('paybras_token', $_POST) ? $_POST['paybras_token'] : (array_key_exists('PAYBRASC_TOKEN', $conf) ? $conf['PAYBRASC_TOKEN'] : '');

		$mensagem_aprovado=array_key_exists('paybras_mensagem_aprovado', $_POST) ? $_POST['paybras_mensagem_aprovado'] : (array_key_exists('PAYBRASC_MENSAGEM_APROVADO', $conf) ? $conf['PAYBRASC_MENSAGEM_APROVADO'] : '');
		
		$mensagem_cancelado=array_key_exists('paybras_mensagem_cancelado', $_POST) ? $_POST['paybras_mensagem_cancelado'] : (array_key_exists('PAYBRASC_MENSAGEM_CANCELADO', $conf) ? $conf['PAYBRASC_MENSAGEM_CANCELADO'] : '');
		
		$mensagem_em_analise=array_key_exists('paybras_mensagem_em_analise', $_POST) ? $_POST['paybras_mensagem_em_analise'] : (array_key_exists('PAYBRASC_MENSAGEM_EM_ANALISE', $conf) ? $conf['PAYBRASC_MENSAGEM_EM_ANALISE'] : '');
		
		$status1=array_key_exists('paybras_status1', $_POST) ? $_POST['paybras_status1'] : (array_key_exists('PAYBRASC_STATUS1', $conf) ? $conf['PAYBRASC_STATUS1'] : '');
		$status2=array_key_exists('paybras_status2', $_POST) ? $_POST['paybras_status2'] : (array_key_exists('PAYBRASC_STATUS2', $conf) ? $conf['PAYBRASC_STATUS2'] : '');
		
		$status3=array_key_exists('paybras_status3', $_POST) ? $_POST['paybras_status3'] : (array_key_exists('PAYBRASC_STATUS3', $conf) ? $conf['PAYBRASC_STATUS3'] : '');
		
		$status4=array_key_exists('paybras_status4', $_POST) ? $_POST['paybras_status4'] : (array_key_exists('PAYBRASC_STATUS4', $conf) ? $conf['PAYBRASC_STATUS4'] : '');
		
		$template=array_key_exists('paybras_template', $_POST) ? $_POST['paybras_template'] : (array_key_exists('PAYBRASC_TEMPLATE', $conf) ? $conf['PAYBRASC_TEMPLATE'] : '');

		$status5=array_key_exists('paybras_status5', $_POST) ? $_POST['paybras_status5'] : (array_key_exists('PAYBRASC_STATUS5', $conf) ? $conf['PAYBRASC_STATUS5'] : '');
		 
		$status6=array_key_exists('paybras_status6', $_POST) ? $_POST['paybras_status6'] : (array_key_exists('PAYBRASC_STATUS6', $conf) ? $conf['PAYBRASC_STATUS6'] : '');
		
		$status7=array_key_exists('paybras_status7', $_POST) ? $_POST['paybras_status7'] : (array_key_exists('PAYBRASC_STATUS7', $conf) ? $conf['PAYBRASC_STATUS7'] : '');
		
		$status8=array_key_exists('paybras_status8', $_POST) ? $_POST['paybras_status8'] : (array_key_exists('PAYBRASC_STATUS8', $conf) ? $conf['PAYBRASC_STATUS8'] : '');
		 
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
		<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Configurações').'</legend>
			<label>'.$this->l('E-mail da sua conta Paybrás').':</label>
			<div class="margin-form"><input type="text" size="33" name="paybras_email" value="'.htmlentities($email, ENT_COMPAT, 'UTF-8').'" /></div>
			<br />
			
			<label>TOKEN</label>
			<div class="margin-form"><input type="text" size="60" name="paybras_token" value="'.$token.'" /></div>
			<br />
			
			<label>'.$this->l('Template').':</label>
			<div class="margin-form">'.$this->getCombo('paybras_template', array(1=>'Cartão Azul', 2=>'Cartão Rosa',3=>'Cartão Verde',4=>'Cartão Vermelho', 5=>'Cartão Cinza', 6=>'Cartão Roxo', 'S'=>'Formulário Simples'), $template).'</div>
			<br />
			
			<h1>Status dos Pedidos</h1>
			<P>Selecione abaixo os status que devem ser assumidos nas compras de acordo com o estado do pagamento. Caso queira criar mais status em sua loja, acessoe o menu COMPRAS e escolha a opção STATUS.</P>
			
			<label>Aguardando Pagamento</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status1', $status1).'</div>
			<br />
			
			<label>Em Análise</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status2', $status2).'</div>
			<br />
			
			<label>Aprovado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status3', $status3).'</div>
			<br />
			
			<label>Não Autorizado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status4', $status4).'</div>
			<br />
			
			<label>Recusado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status5', $status5).'</div>
			<br />
			
			<label>Devolvido</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status6', $status6).'</div>
			<br />
			
			<label>Chargeback em Análise</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status7', $status7).'</div>
			<br />
			
			<label>Erro no pagamento</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status8', $status8).'</div>
			<br />
			
			
			<h1>Mensagens de pagamento</h1>
			
			<label>Mensagem para pagamentos Em Análise</label>
			<div class="margin-form"><textarea name="paybras_mensagem_em_analise" cols="80" rows="5">'.$mensagem_em_analise.'</textarea></div>
			<br />

			
			<label>Mensagem para pagamentos Cancelados</label>
			<div class="margin-form"><textarea name="paybras_mensagem_cancelado" cols="80" rows="5">'.$mensagem_cancelado.'</textarea></div>
			<br />
			
			<label>Mensagem para pagamentos Aprovados</label>
			<div class="margin-form"><textarea name="paybras_mensagem_aprovado" cols="80" rows="5">'.$mensagem_aprovado.'</textarea></div>
			<br />
			
			<center><input type="submit" name="submitPaybras" value="'.$this->l('Atualizar').'" class="button" /></center>
		</fieldset>
		</form>';
		
		
	}


	public function hookPayment($params)
	{
		
		global $smarty;
		$smarty->assign(array(
			
			'imgBtn' => "modules/paybrasc/img/cartoes.gif",
			'this_path' => $this->_path, 'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
			'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,
			'UTF-8') . __PS_BASE_URI__ . 'modules/' . $this->name . '/'));
			
			
			
		return $this->display(__file__, 'payment.tpl');
		
	}
	public function xml2array($contents, $get_attributes=1, $priority = 'tag') 
	{ 
    if(!$contents) return array(); 

    if(!function_exists('xml_parser_create')) { 
     
        return array(); 
    } 

    $parser = xml_parser_create(''); 
    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0); 
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1); 
    xml_parse_into_struct($parser, trim($contents), $xml_values); 
    xml_parser_free($parser); 

    if(!$xml_values) return;

    $xml_array = array(); 
    $parents = array(); 
    $opened_tags = array(); 
    $arr = array(); 

    $current = &$xml_array;

    $repeated_tag_index = array();
    foreach($xml_values as $data) { 
        unset($attributes,$value);

        extract($data);
		
        $result = array(); 
        $attributes_data = array(); 
         
        if(isset($value)) { 
            if($priority == 'tag') $result = $value; 
            else $result['value'] = $value; 
        } 

        if(isset($attributes) and $get_attributes) { 
            foreach($attributes as $attr => $val) { 
                if($priority == 'tag') $attributes_data[$attr] = $val; 
                else $result['attr'][$attr] = $val; 
            } 
        } 

        if($type == "open") {
            $parent[$level-1] = &$current; 
            if(!is_array($current) or (!in_array($tag, array_keys($current)))) {
                $current[$tag] = $result; 
                if($attributes_data) $current[$tag. '_attr'] = $attributes_data; 
                $repeated_tag_index[$tag.'_'.$level] = 1; 

                $current = &$current[$tag]; 

            } else {

                if(isset($current[$tag][0])) {
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result; 
                    $repeated_tag_index[$tag.'_'.$level]++; 
                } else {
                    $current[$tag] = array($current[$tag],$result);
                    $repeated_tag_index[$tag.'_'.$level] = 2; 
                     
                    if(isset($current[$tag.'_attr'])) {  
                        $current[$tag]['0_attr'] = $current[$tag.'_attr']; 
                        unset($current[$tag.'_attr']); 
                    } 

                } 
                $last_item_index = $repeated_tag_index[$tag.'_'.$level]-1; 
                $current = &$current[$tag][$last_item_index]; 
            } 

        } elseif($type == "complete") { 
            if(!isset($current[$tag])) { 
                $current[$tag] = $result; 
                $repeated_tag_index[$tag.'_'.$level] = 1; 
                if($priority == 'tag' and $attributes_data) $current[$tag. '_attr'] = $attributes_data; 

            } else { 
                if(isset($current[$tag][0]) and is_array($current[$tag])) {
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result; 
                     
                    if($priority == 'tag' and $get_attributes and $attributes_data) { 
                        $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data; 
                    } 
                    $repeated_tag_index[$tag.'_'.$level]++; 

                } else { 
                    $current[$tag] = array($current[$tag],$result);
                    $repeated_tag_index[$tag.'_'.$level] = 1; 
                    if($priority == 'tag' and $get_attributes) { 
                        if(isset($current[$tag.'_attr'])) { 
                             
                            $current[$tag]['0_attr'] = $current[$tag.'_attr']; 
                            unset($current[$tag.'_attr']); 
                        } 
                         
                        if($attributes_data) { 
                            $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data; 
                        } 
                    } 
                    $repeated_tag_index[$tag.'_'.$level]++; 
                } 
            } 

        } elseif($type == 'close') { 
            $current = &$parent[$level-1]; 
        } 
    } 
     
    return($xml_array); 
} 
	
	public function hookPaymentReturn($params)
    {
		#Descomente a linha abaixo caso precise depurar
		error_reporting(E_ALL); ini_set('display_errors', 'On');
		
        global $smarty;
		
		$referencia=$params['objOrder']->id;
		
		switch($_GET['res'])
		{
			case 1:
				$titulo="O seguinte erro ocorreu:";
				$mensagem=urldecode($_GET['msg']).' - Seu pedido foi <span class="price">Cancelado</span>. Por favor, efetue um novo pedido e corrija seus dados. Se necessário você também poderá escolher uma nova forma de pagamento.';
			break;
			
			case 2:
				$titulo="Obrigado por concluir seu pedido! ";
				$mensagem=Configuration::get('PAYBRASC_MENSAGEM_EM_ANALISE');
			break;
			
			case 3:
			
			switch($_GET['codigo'])
			{
				case 1:
				$m='Transação não foi autorizada pelo emissor. Entre em contato com o banco emissor do cartão.';
				break;
				
				case 2:
				$m='Transação bloqueada pelo emissor. Entre em contato com banco emissor do cartão.';
				break;
				
				case 3:
				$m='Transação não foi autorizada pelo emissor. Entre em contato com o banco emissor para verificar o saldo de seu cartão.';
				break;
				
				case 4:
				$m='Transação não foi autorizada pois o cartão encontra-se bloqueado ou não é habilitado na função crédito. Entre em contato com o banco emissor para desbloqueá-lo.';
				break;
				
				case 6:
				$m='Dados do cartão inválidos ou cartão encontra-se vencido. Tente novamente.';
				break;
				
				case 7:
				$m='Transação falhou. Tente novamente.';
				break;
				
				case 8:
				$m='Não foi possível processar a transação.';
				break;
				
				case 9:
				$m='Transação não autorizada.';
				break;
				
				case 12:
				$m='Transação falhou.';
				break;
				
				default: $m=''; break;
				
				
			}
			$titulo="Recebimento não autorizado";
			
			$mensagem=Configuration::get('PAYBRASC_MENSAGEM_CANCELADO');
			
			if($m)
			$mensagem .="<BR><BR>Motivo retornado: ".$m.'<BR>';
			break;
			
			case 4:
			
				$titulo="Obrigado por concluir seu pedido!";
				$mensagem=Configuration::get('PAYBRASC_MENSAGEM_APROVADO');
			break;
			
			case 8:
				$titulo="Um erro ocorreu";
				$mensagem='Seu pagamento não foi efetuado com sucesso. O seguinte erro ocorreu: ';
			
			
			break;
			
			case 5:
				$titulo="Um erro desconhecido ocorreu";
				$mensagem='Um erro desconhecido ocorreu e seu pedido foi Cancelado. Caso seja a primeira vez que está recebendo essa mensagem, por favor, efetue um novo pedido e confira atentamente a todos os seus dados. Caso já tenha recebido essa mensagem anteriormente, por favor, entre em contato através do e-mail'.Configuration::get('PAYBRASC_EMAIL').' e informe o ocorrido. Desculpe pelo inconveniente.';
			break;
			
			
		}
		
		
		$smarty->assign(array(
			'status' 		=> 'ok', 
			'id_order' 		=> $params['objOrder']->id,
			'secure_key' 	=> $params['objOrder']->secure_key,
			'id_module' 	=> $this->id,
			'url_loja'		=> __PS_BASE_URI__,
			'titulo'		=> $titulo,
			'mensagem'		=> $mensagem
		));
		
		return $this->display(__file__, 'payment_return.tpl');
    }
	
	public function parcelar($valorTotal, $taxa, $nParcelas)
	{
		$taxa = $taxa/100;
		$cadaParcela = ($valorTotal*$taxa)/(1-(1/pow(1+$taxa, $nParcelas)));
		return round($cadaParcela, 2);
	}
    
	
	/*public function hookdisplayHeader($params)
	{
		$this->context->controller->addCSS(($this->_path).'css/estilos.css', 'all');
		$this->context->controller->addJS(($this->_path).'js/validacao.js', 'all');
		$this->context->controller->addJS(($this->_path).'js/messi.min.js', 'all');

	}
    */
    function getStatus($param)
    {
    	global $cookie;
    		
    		$sql_status = Db::getInstance()->Execute
		('
			SELECT `name`
			FROM `'._DB_PREFIX_.'order_state_lang`
			WHERE `id_order_state` = '.$param.'
			AND `id_lang` = '.$cookie->id_lang.'
			
		');
		
		return mysql_result($sql_status, 0);
    }
	
	public function getUrlByMyOrder($myOrder)
	{

		$module				= Module::getInstanceByName($myOrder->module);			
		$pagina_qstring		= __PS_BASE_URI__."order-confirmation.php?id_cart="
							  .$myOrder->id_cart."&id_module=".$module->id."&id_order="
							  .$myOrder->id."&key=".$myOrder->secure_key;			
		
		if	(	@$_SERVER['HTTPS']	!=	"on"	)
		$protocolo			=	"http";
		
		else
		$protocolo			=	"https";
		
		$retorno 			= $protocolo . "://" . $_SERVER['SERVER_NAME'] . $pagina_qstring;	
				
		return $retorno;

	}
	
	public function hookHeader($params)
	{
		if(@Context::getContext()->controller->page_name=='module-paybrasc-pagar')
		{
			$this->context->controller->addJS('https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/jquery.maskedinput.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/messi.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/validacao.js', 'all');
			$this->context->controller->addCSS(($this->_path).'css/estilos.css', 'all');
			$this->context->controller->addCSS(($this->_path).'css/messi.min.css', 'all');
			
			$this->context->controller->addCSS(($this->_path).'css/bootstrap/bootstrap.min.css', 'all');
			#$this->context->controller->addCSS(($this->_path).'css/bootstrap/bootstrap-theme.min.css', 'all');
		}
	}
	
	public function hookHeade2($params)
	{
		$this->context->controller->addJs('"https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js');
		
		return '
		
		<link href="" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-theme.min.css">
		
		';
	}
	
	public function hookAdminOrder($params){
		
		
		
		$res=Db::getInstance()->ExecuteS('SELECT * FROM `'._DB_PREFIX_.'transacoes_paybras` WHERE id_order='.$params['id_order']);

	if(@$res[0]['nome'])
	{
	$html = '<div class="col-lg-14"><div class="panel">';

	$html .= '<fieldset style="width:100%;"><legend><img width="18" height="18" src="'._PS_BASE_URL_.__PS_BASE_URI__.'modules/'.$this->name.'/logo.gif" alt="" /> 

'.$this->l('Informações da Transação PAYBRÁS').'</legend></fieldset>';

	$html .='<table width="100%" border="0" cellspacing="3" cellpadding="3">
  <tr>
    <th>ID</th>
    <th>NOME</th>
    <th>BANDEIRA</th>
    <th>BIN</th>
  </tr>
  <tr>
    <td><a href="https://painel.paybras.com/admin/Transactions/transaction_details/'.$res[0]['id_transacao'].'" target="_blank">'.$res[0]['id_transacao'].'</a></td>
    <td>'.$res[0]['nome'].'</td>
    <td>'.$res[0]['bandeira'].'</td>
    <td>'.$res[0]['bin'].'</td>
  </tr>
  <tr>
    <th>TELEFONE</th>
    <th>CPF</th>
    <th>IP</th>
    <th>PARCELAS</th>
  </tr>
  <tr>
    <td>'.$res[0]['telefone'].'</td>
    <td>'.$res[0]['cpf'].'</td>
    <td>'.$res[0]['ip'].'</td>
    <td>'.$res[0]['parcelas'].'</td>
  </tr>
  ';



if($res[0]['codigo_nao_autorizado']>0)
{
	switch($res[0]['codigo_nao_autorizado'])
			{
				case 1:
				$m='Transação não foi autorizada pelo emissor. Entre em contato com o banco emissor do cartão.';
				break;
				
				case 2:
				$m='Transação bloqueada pelo emissor. Entre em contato com banco emissor do cartão.';
				break;
				
				case 3:
				$m='Transação não foi autorizada pelo emissor. Entre em contato com o banco emissor para verificar o saldo de seu cartão.';
				break;
				
				case 4:
				$m='Transação não foi autorizada pois o cartão encontra-se bloqueado ou não é habilitado na função crédito. Entre em contato com o banco emissor para desbloqueá-lo.';
				break;
				
				case 6:
				$m='Dados do cartão inválidos ou cartão encontra-se vencido. Tente novamente.';
				break;
				
				case 7:
				$m='Transação falhou. Tente novamente.';
				break;
				
				case 8:
				$m='Não foi possível processar a transação.';
				break;
				
				case 9:
				$m='Transação não autorizada.';
				break;
				
				case 12:
				$m='Transação falhou.';
				break;
				
				default: $m=''; break;
				
			}
	
	$html .='<TR><td colspan="4"></TD></TR><TR><td colspan="4"></TD></TR><tr>
    <td colspan="4">MOTIVO DA NÃO AUTORIZAÇÃO DO PAGAMENTO - '.$res[0]['codigo_nao_autorizado'].' - '.$m.'</td>
  </tr><TR><td colspan="4"></TD></TR>
  ';
	
	
}

$html .='</table>';


	$html .= '</div></div><div class="clearfix"/>';

	}
	else $html= "";


	

	return $html;

	}


    
}
?>