<?php
/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
$useSSL = true;

require('../../config/config.inc.php');
Tools::displayFileAsDeprecated();

$controller = new FrontController();
$controller->init();

Tools::redirect(Context::getContext()->link->getModuleLink('paybrasc', 'pagar'));

?>