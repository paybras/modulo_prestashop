﻿<?php 
/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
 class PaybrasCPagarModuleFrontController extends ModuleFrontController{
	
	public function initContent() {
		$mpag = new PaybrasC();
		$this->display_column_left = false;
		$this->ssl = true;
		$this->display_column_right=false;
		parent::initContent();
		
		 global $cookie, $smarty, $cart;
			
        $invoiceAddress 	= new Address(intval($cart->id_address_invoice));
        $customerPag 		= new Customer(intval($cart->id_customer));
        $currencies 		= Currency::getCurrencies();
        $currencies_used 	= array();
		$currency 			= $mpag->getCurrency();

        $currencies 		= Currency::getCurrencies();		
	
		
        foreach ($currencies as $key => $currency)
            $smarty->assign(array(
                'token' => Configuration::get('PAYBRASC_TOKEN'),
                'currency_default' => new Currency(Configuration::get('PS_CURRENCY_DEFAULT')),
                'currencies' => $currencies_used, 
                'imgBtn' => "img/cartoes.gif",

                'currency_default' => new Currency(Configuration::get('PS_CURRENCY_DEFAULT')),
                'currencies' => $currencies_used, 
                'total' => number_format(Tools::convertPrice($cart->getOrderTotal(true, 3), $currency), 2, '.', ''), 
                'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
                'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,'UTF-8') . __PS_BASE_URI__ . 'modules/' . $mpag->name . '/'));
			
			
		
		$valor=number_format($cart->getOrderTotal(true, 3), 2, '.', '');
		$maximo_parcelas=12;
		$juros=2.49;
		$semjuros=1;
		
		
		if($valor>5) 
		{
			$splitss = (int) ($valor/5);
			
			if($splitss<=$maximo_parcelas)
			{
				$total_parcelas = $splitss;
			}
			else
			{
				$total_parcelas = $maximo_parcelas;
			}
		}
		else
		{
			$total_parcelas = 1;
		}
		
		#calcula o parcelamento de acordo com o valor do pedido. A parcela mínima do Paybrás é de 5 reais
	
		$parcelamento='<UL id="lista_de_parcelas">';
		
		
		for($j=1; $j<=$total_parcelas;$j++) 
		{
		
			if($semjuros>=$j) 
			{
			
				$parcelas = $valor/$j;
				$parcelas = number_format($parcelas, 2, '.', '');
				
				$parcelamento .= '<option value="'.$j.'">'.$j.'x de R$'.number_format($parcelas, 2,',', '.').' Sem Juros</option>';
				
				
				
			}
			else
			{
			
				$parcelas = $mpag->parcelar($valor, $juros, $j);
				$parcelas = number_format($parcelas, 2, '.', '');
				
				$parcelamento .= '<option value="'.$j.'">'.$j.'x de R$'.number_format($parcelas, 2,',', '.').' Com Juros de '.number_format($juros, 2, ',', ',').'% A.M.</option>
				
				';
				
				
			}
		
		}
		
		$parcelamento .='</UL>';
		#Calcula anos da validade do cartão
		
		$anos_validade_cartao='';
		
		for($i=date('Y'); $i<=(date('Y')+10); $i++)
		{
			@$anos_validade_cartao .='<option value="'.($i-2000).'">'.$i.'</option>';
		}

		$device=md5(session_id().time()).'80200';
$cep =  str_replace(array('-','.'),'',$invoiceAddress->postcode);
$cep = substr($cep,0,5) .'-'. substr($cep,5,3);

	$template=Configuration::get('PAYBRASC_TEMPLATE');
	
	$smarty->assign(array(
            'anos_validade_cartao'	=> $anos_validade_cartao,
            'parcelamento'			=> $parcelamento,
			'device' => $device,
			'fatura_estado' => Db::getInstance()->getValue('SELECT iso_code FROM '._DB_PREFIX_.'state WHERE id_state='. $invoiceAddress->id_state), 
			'fatura_nome'=>$invoiceAddress->firstname .' '.$invoiceAddress->lastname,
			'fatura_endereco'=>$invoiceAddress->address1,
			'fatura_bairro' => $invoiceAddress->address2,
			'fatura_cep' =>$cep,
			'fatura_cidade' => $invoiceAddress->city,
			'template'	=> Configuration::get('PAYBRASC_TEMPLATE')
		));

		if(is_numeric($template))
		{
			 $template='payment_execution.tpl';
		}
		else
		{
			switch($template)
			{
			case 'S': #template simples
			
				$template=('simples.tpl');
			break;	
				
			}
			
			#return
		}
       $this->setTemplate($template);
	   ob_clean();
	}
} ?>