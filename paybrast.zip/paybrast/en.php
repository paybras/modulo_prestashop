<?php

/**
 * @author Andresa 
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 * @version 1.0 Beta
 **/
 
global $_MODULE;
$_MODULE = array();

?>
