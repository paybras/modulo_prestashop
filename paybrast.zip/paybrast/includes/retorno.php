<?php
/**
 * @author Andresa - contato@andresa.com.br
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/

include(dirname(__FILE__).'/../../../config/config.inc.php');


include(dirname(__FILE__).'/../paybrast.php');


$retorno= json_decode($_POST['data']);


if ($retorno->recebedor_api_token==Configuration::get('PAYBRAST_TOKEN'))
{
		if($retorno->transacao_recuperada_id)
		{
			#é uma transação recuperada, seleciona e atualiza	
			$id_transacao 		= Db::getInstance()->getValue("SELECT 

id_order FROM "._DB_PREFIX_."orders WHERE id_transacao_paybras='".$retorno->transacao_id."' ");

			#atualiza com a id de transacao nova
			
			Db::getInstance()->ExecuteS("UPDATE "._DB_PREFIX_."orders SET id_transacao_paybras='".$retorno->transacao_id."' WHERE id_order=".$id_transacao);
			
			
		}
	    $id_transacao 		= Db::getInstance()->getValue("SELECT 

id_order FROM "._DB_PREFIX_."orders WHERE id_transacao_paybras='".$retorno->transacao_id."' ");



        $status_pagamento 	= $retorno->status_codigo;

        $order 				= new Order(intval($id_transacao));
        $cart 				= Cart::getCartByOrderId($id_transacao);

		switch($status_pagamento)
		{
			case 4: #aprovado
				$status = Configuration::get('PAYBRAST_STATUS2');
			break;

			/*case 5: #recusado
			case 3:
				$status = Configuration::get('PAYBRAST_STATUS4');
			break;*/
			
			
			case 6: #devolvido
				$status = Configuration::get('PAYBRAST_STATUS5');
			break;
			
			case 9: #cancelado
			
				$status = Configuration::get('PAYBRAST_STATUS3');
			break;
		
		}


			
		
		$objOrder = new Order($id_transacao); 
		$history = new OrderHistory();
		$history->id_order = (int)$objOrder->id;
		$history->changeIdOrderState($status, (int)($objOrder->id)); 

		$history->addWithemail(true);
		
		
		$ret['retorno'] = 'ok';
		return json_encode($ret);	
		
}

?>