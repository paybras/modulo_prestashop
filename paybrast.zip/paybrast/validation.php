<?php
/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/../../header.php');

function get_ip()
{
    $keys = array(
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    );
    
    foreach ($keys as $key) {
        if (array_key_exists($key, $_SERVER)) {
            if (filter_var($_SERVER[$key], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
                return $_SERVER[$key];
            }
        }
    }
}


$currency = new Currency(((Tools::getValue('currency_payement')!=null) ? Tools::getValue('currency_payement') : $cookie->id_currency));
$total    = (number_format($cart->getOrderTotal(true, 3), 2, '.', ''));

$paybrast = new PaybrasT();

$mailVars = array(
    '{bankwire_owner}' => $paybrast->textshowemail,
    '{bankwire_details}' => '',
    '{bankwire_address}' => ''
);




$paybrast->validateOrder($cart->id, Configuration::get('PAYBRAST_STATUS1'), $total, $paybrast->displayName, NULL, $mailVars, $currency->id);


$order      = new Order($paybrast->currentOrder);
$idCustomer = $order->id_customer;
$idLang     = $order->id_lang;
$customer   = new Customer(($idCustomer));
$CusMail    = $customer->email;

$mailVars = array(
    '{email}' => Configuration::get('PS_SHOP_EMAIL'),
    '{firstname}' => Tools::stripslashes($customer->firstname),
    '{lastname}' => Tools::stripslashes($customer->lastname),
    '{terceiro}' => Tools::stripslashes($paybrast->displayName),
    '{id_order}' => Tools::stripslashes($paybrast->currentOrder),
    '{status}' => Tools::stripslashes($novo_status),
    '{link}' => $paybrast->getUrlByMyOrder($order)
);

$id_compra = $order->id;

$order_products = $order->getProducts();

$assunto = $novo_status;

/*

Seleciona o endereço da fatura para enviar
ao gateway da PayBras. Mais informações sobre o assunto adiante

*/
$conexao = mysql_connect(_DB_SERVER_, _DB_USER_, _DB_PASSWD_);
mysql_select_db(_DB_NAME_, $conexao);

$query_endereco = mysql_query('
        SELECT a.`id_state`, a.`id_customer`, a.`firstname` nome, a.`lastname` sobrenome, 
        a.`address1` endereco, a.`address2` complemento, a.`postcode` cep, a.`city` cidade, c.`email`, a.`phone`, a.`phone_mobile` 
        FROM `' . _DB_PREFIX_ . 'address` a, `' . _DB_PREFIX_ . 'customer` c
        WHERE a.`id_address`=' . $cart->id_address_invoice . ' AND c.`id_customer`=a.`id_customer` LIMIT 1', $conexao);

$query_state = mysql_query('
        SELECT `iso_code`
        FROM `' . _DB_PREFIX_ . 'state` s
        left join `' . _DB_PREFIX_ . 'address` a
            on s.`id_state` = a.`id_state`
        WHERE a.`id_address`=' . $cart->id_address_delivery . '', $conexao);

$endereco = mysql_fetch_object($query_endereco);
$estado   = mysql_fetch_object($query_state);

$endereco->celular  = Tools::substr(preg_replace("/[^0-9]/", "", $endereco->phone_mobile), 0, 11);


$query_endereco = mysql_query('
        SELECT a.`id_state`, a.`id_customer`, a.`firstname` nome, a.`lastname` sobrenome, 
        a.`address1` endereco, a.`address2` complemento, a.`postcode` cep, a.`city` cidade, c.`email`, a.`phone`, a.`phone_mobile` 
        FROM `' . _DB_PREFIX_ . 'address` a, `' . _DB_PREFIX_ . 'customer` c
        WHERE a.`id_address`=' . $cart->id_address_invoice . ' AND c.`id_customer`=a.`id_customer` LIMIT 1', $conexao);

$query_state = mysql_query('
        SELECT `iso_code`
        FROM `' . _DB_PREFIX_ . 'state` s
        left join `' . _DB_PREFIX_ . 'address` a
            on s.`id_state` = a.`id_state`
        WHERE a.`id_address`=' . $cart->id_address_invoice . '', $conexao);

$endereco2 = mysql_fetch_object($query_endereco);
$estado2   = mysql_fetch_object($query_state);

if(!$endereco) $endereco=$endereco2;
if(!$estado) $estado=$estado2;


if (Configuration::get('PS_SSL_ENABLED'))
    $url_retorno = _PS_BASE_URL_SSL_ . __PS_BASE_URI__ . "modules/paybrast/includes/retorno.php";
else
    $url_retorno = _PS_BASE_URL_ . __PS_BASE_URI__ . "modules/paybrast/includes/retorno.php";

$telefone_ddd=substr($_POST['telefone'], 1, 2);
$telefone_numero=substr($_POST['telefone'], 4,9);

	
	$dados['recebedor_api_token'] = Configuration::get('PAYBRAST_TOKEN');
	$dados['recebedor_email'] = Configuration::get('PAYBRAST_EMAIL');
	$dados['pedido_id'] = $id_compra;
	$dados['pedido_descricao'] = 'Pedido '.$id_compra.' efetuado em '._PS_BASE_URL_.__PS_BASE_URI__;
	$dados['pedido_meio_pagamento'] = $_POST['banco'];
	$dados['pedido_moeda'] = 'BRL';
	$dados['pedido_valor_total_original'] = $cart->getOrderTotal(true);
	$dados['pagador_nome'] = utf8_encode($endereco2->nome." ".$endereco2->sobrenome);
	$dados['pagador_email'] = $endereco2->email;
	$dados['pagador_cpf'] = $_POST['cpf'];
	$dados['pagador_rg'] = '';
	$dados['pagador_telefone_ddd'] = $telefone_ddd;
	$dados['pagador_telefone'] = $telefone_numero;
	#$dados['pagador_sexo'] = '';
	#$dados['pagador_data_nascimento'] = '05/02/1988';
	
	$dados['pagador_ip'] = get_ip();
	$dados['pagador_logradouro'] = utf8_encode($endereco2->complemento);
	$dados['pagador_numero'] = 'x';
	$dados['pagador_complemento'] =utf8_encode($endereco2->complemento);
	$dados['pagador_bairro'] =utf8_encode($endereco2->complemento);
	$dados['pagador_cep'] =  $endereco->cep;
	$dados['pagador_cidade'] =  utf8_encode($endereco2->cidade) ;
	$dados['pagador_estado'] = $estado2->iso_code;
	
	$dados['pagador_pais'] = 'BRA';
	$dados['entrega_nome'] = utf8_encode($endereco->nome." ".$endereco->sobrenome);
	$dados['entrega_estado'] = $estado->iso_code;
	$dados['entrega_pais'] = 'BRA';
	$dados['entrega_logradouro'] = utf8_encode($endereco->endereco);
	$dados['entrega_numero'] = 'x';
	$dados['entrega_complemento'] = utf8_encode($endereco->complemento);
	$dados['entrega_bairro'] = utf8_encode($endereco->complemento);
	$dados['entrega_cep'] = $endereco->cep;
	$dados['entrega_cidade'] = utf8_encode($endereco->cidade);
	$dados['pedido_url_redirecionamento']=_PS_BASE_URL_.__PS_BASE_URI__ . 'order-confirmation.php?id_cart=' . $cart->id . '&id_module=' . $paybrast->id . '&id_order=' . $paybrast->currentOrder . '&res=7&key=' . $order->secure_key;
	
	foreach($order_products as $order_product) 
	{
		$object = new stdClass();
		$produto =  array('produto_codigo'=>$order_product['product_id'], 'produto_nome'=>$order_product['product_name'],'produto_categoria'=>'','produto_valor'=>number_format($order_product['unit_price_tax_incl'], 2, '.', ''),'produto_qtd'=>$order_product['product_quantity'],'produto_peso'=>0);
		
		foreach ($produto as $key => $value)
		{
			$object->$key = $value;
		}
		$dados['produtos'][] = $object;
	}
	
	$data_string=json_encode($dados);
	
	if(Configuration::get('PAYBRAST_SANDBOX')==1)
		$url='https://service.paybras.com/payment/api/criaTransacao';
	else
		$url='https://sandbox.paybras.com/payment/api/criaTransacao';

	$ch = curl_init();

        
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
        );

	$resultado=(json_decode((curl_exec($ch))));
	
	$status = $resultado->status_codigo;    
    $transacao = $resultado->transacao_id; 
	$url_pagamento=$resultado->url_pagamento;
	

/*
De acordo com  o retorno do PAYBRAS, define a mensagem
que aparecerá na página final do pagamento.

*/


$sql = "UPDATE " . _DB_PREFIX_ . "orders SET id_transacao_paybras='" . $transacao . "', url_boleto_paybras='" . $url_pagamento . "' WHERE id_order=" . $id_compra . " LIMIT 1";

Db::getInstance()->Execute($sql);


if ($status == 1) {
    $fim_url     = '&res=2&boleto=' . urlencode($url_pagamento).'&banco='.$_POST['banco'];
    $novo_status = Configuration::get('PAYBRAST_STATUS1');
} else {
    $fim_url     = '&res=1&msg=' . urlencode('Um erro ocorreu. Por favor, confira seus dados e tente novamente.');
    $novo_status = (Configuration::get('PAYBRAST_STATUS3'));
}


$objOrder          = new Order($id_compra); //order with id=1
$history           = new OrderHistory();
#$objOrder->setCurrentState($id_compra);
$history->id_order = (int) $objOrder->id;
$history->changeIdOrderState($novo_status, (int) ($objOrder->id)); //order status=3
$history->addWithemail(true);

    if(Configuration::get('PAYBRAST_REDIRECIONA')==1 && $status == 1)
	{
		Tools::redirectLink($url_pagamento); exit;
	}

Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?id_cart=' . $cart->id . '&id_module=' . $paybrast->id . '&id_order=' . $paybrast->currentOrder . '&key=' . $order->secure_key . $fim_url . '&transacao='. ($transacao));

?>