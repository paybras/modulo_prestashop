<?php

/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/

class PaybrasT extends PaymentModule
{
	private $_html 			= '';
    private $_postErrors 	= array();
    public $currencies;
	private $status;
		
	public function __construct()
    {
        $this->name 			= 'paybrast';
        $this->tab 				= 'payments_gateways';
        $this->version 			= '1.0';
		$this->author			= "www.consultoriadaweb.com.br";
        $this->currencies 		= true;
        $this->currencies_mode 	= 'radio';
	
		
        parent::__construct();

        $this->page 			= basename(__file__, '.php');
        $this->displayName 		= $this->l('Paybrás - Transferência Eletrônica');
        $this->description 		= $this->l('Permite receber pagamentos com TEF através do gateway Paybrás');
		$this->confirmUninstall = $this->l('Tem certeza de que pretende eliminar os seus dados?');
		$this->textshowemail 	= $this->l('Você receberá por mensagens por e-mail informando a cadaatualização da sua compra.');
	}
	
	public function install()
	{
		
		
        $this->create_paybras_transacoes_table();

		if(!$email=Configuration::get('PAYBRAST_EMAIL'))
			$email='paybras@seudominio.com.br';
			
		if(!$token=Configuration::get('PAYBRAST_TOKEN'))
			$token='';
			
		if(!$status1=Configuration::get('PAYBRAST_STATUS1'))
		$status1='';
			
		if(!$status2=Configuration::get('PAYBRAST_STATUS2'))
			$status2='';
			
		if(!$status3=Configuration::get('PAYBRAST_STATUS3'))
			$status3='';
			
		if(!$status4=Configuration::get('PAYBRAST_STATUS4'))
			$status4='';
			
		if(!$status5=Configuration::get('PAYBRAST_STATUS5'))
			$status5='';
			
		if(!$mpagamento=Configuration::get('PAYBRAST_MENSAGEM_PAGAMENTO'))
			$mpagamento='Para efetuar o pagamento de seu pedido, clique no link abaixo. Você será redirecionado para a página do seu banco.';
		if(!$mpagamento2=Configuration::get('PAYBRAST_MENSAGEM_SUCESSO'))
			$mpagamento2='Seu pagamento foi concluído com sucesso! Em breve seu pedido começará a ser processado.';

		if 
		(
			!parent::install() 
		OR 	!Configuration::updateValue('PAYBRAST_EMAIL', $email)
		OR 	!Configuration::updateValue('PAYBRAST_TOKEN', 	  $idcomercio)
		OR 	!Configuration::updateValue('PAYBRAST_STATUS1', 	  $status1)
		OR 	!Configuration::updateValue('PAYBRAST_STATUS2', 	  $status2)
		OR 	!Configuration::updateValue('PAYBRAST_REDIRECIONA', 	  1)
		OR 	!Configuration::updateValue('PAYBRAST_SANDBOX', 	  1)
		OR 	!Configuration::updateValue('PAYBRAST_BTN', 	  0)  
		
		OR 	!Configuration::updateValue('PAYBRAST_MENSAGEM_PAGAMENTO', 	 $mpagamento) 
		OR 	!Configuration::updateValue('PAYBRAST_MENSAGEM_SUCESSO', 	 $mpagamento2) 
		OR 	!Configuration::updateValue('PAYBRAST_MENSAGEM_EM_ANALISE',   'Seu pagamento encontra-se <span class="price">Em Análise</span> pela operadora do seu cartão de crédito. Você receberá um e-mail automático informando quando o mesmo for aprovado.') 

		OR 	!$this->registerHook('payment') 
		OR 	!$this->registerHook('paymentReturn')
		OR 	!$this->registerHook('header')
		)
			return false;
			
		return true;
	}


    public function create_paybras_transacoes_table()
    {
		try {
    
			@Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'orders` ADD `id_transacao_paybras` VARCHAR(36) NULL ;');
			
			} catch (Exception $e) {}

		try {
    
			@Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'transacoes_paybras` (
			  `id_order` int(11) NOT NULL,
			  `meio_pagamento` char(1) NOT NULL,
			  `ip` varchar(15) NOT NULL,
			  `nome` varchar(30) NOT NULL,
			  `bandeira` varchar(20) NOT NULL,
			  `bin` varchar(20) NOT NULL,
			  `telefone` varchar(15) NOT NULL,
			  `cpf` varchar(14) NOT NULL,
			  `id_transacao` int(11) NOT NULL,
			  `codigo_nao_autorizado` int(11) NOT NULL,
			  `recuperada` int(11) NOT NULL,
			  `parcelas` int(11) NOT NULL,
			  PRIMARY KEY (`id_order`)
			) ;
			');
		} catch (Exception $e) { }

    }

	public function uninstall()
	{
		if 
		(	!parent::uninstall()
		) 
			return false;
		
		return true;
	}
	
	private function setStatus()
	{
		global $cookie;
		$id_lang = $cookie->id_lang;

		$sql="SELECT name, id_order_state FROM "._DB_PREFIX_."order_state_lang WHERE id_lang=".$id_lang."";
		
		
		$this->status=Db::getInstance()->ExecuteS($sql);
	}
	
	private function selectOpcoes($nome, $opcoes, $selecionado=false)
	{
		$s='';
		
		foreach($opcoes as $i=> $valor)
		{
		if($i==$selecionado) $sell='checked'; else $sell='';
		$s .='<label for="radio_'.$nome.'_'.$i.'"><input type="radio" name="'.$nome.'" id="radio_'.$nome.'_'.$i.'" value="'.$i.'" '.$sell.'>
'.$valor .'</label>';	
		}

		return $s;
			
	}
	
	private function getComboStatus($nome, $selecionado=false)
	{
		if(!$this->status)
			$this->setStatus();
		$combo='<select name="'.$nome.'" id="'.$nome.'">';
		
		for($i=0; $i < count($this->status); $i++)
		{
			if($this->status[$i]['id_order_state']!=$selecionado)
				$combo .='<option value="'.$this->status[$i]['id_order_state'].'" >'.$this->status[$i]['name'].'</option>>';
			else
				$combo .='<option value="'.$this->status[$i]['id_order_state'].'" selected="selected">'.$this->status[$i]['name'].'</option>>';
			
		}
		
		$combo .="</select>";
		
		return ($combo);
		
	}
	
	private function getCombo($nome, $opcoes, $selecionado=false)
	{
		$combo='<select name="'.$nome.'" id="'.$nome.'">';
		
		foreach($opcoes as $i=> $valor)
		{
			if($i!=$selecionado)
				$combo .='<option value="'.$i.'" >'.$valor.'</option>>';
			else
				$combo .='<option value="'.$i.'" selected="selected">'.$valor.'</option>>';
			
		}
		
		$combo .="</select>";
		
		return ($combo);
		
		
	}

	public function getContent()
	{
		/*
			Essa função é responsável por salvar os dados da configuração
		*/
		$this->_html = '<h2>Paybrás - Transferência Bancária</h2>';
		
		if (isset($_POST['submitPaybras']))
		{
			if (empty($_POST['paybras_email'])) $this->_postErrors[] = $this->l('E-mail da conta Paybrás');
			elseif (!Validate::isEmail($_POST['paybras_email'])) $this->_postErrors[] = $this->l('Digite um e-mail válido!');
			
				if (!sizeof($this->_postErrors)) 
				{
						Configuration::updateValue('PAYBRAST_EMAIL', $_POST['paybras_email']);
						
						if (!empty($_POST['paybras_redireciona']))
						{
							Configuration::updateValue('PAYBRAST_REDIRECIONA', trim($_POST['paybras_redireciona']));
						}
						
						if (!empty($_POST['paybras_template']))
						{
							Configuration::updateValue('PAYBRAST_TEMPLATE', trim($_POST['paybras_template']));
						}
						
						if (!empty($_POST['paybras_mensagem_pagamento']))
						{
							Configuration::updateValue('PAYBRAST_MENSAGEM_PAGAMENTO', trim($_POST['paybras_mensagem_pagamento']));
						}
						
						if (!empty($_POST['paybras_mensagem_sucesso']))
						{
							Configuration::updateValue('PAYBRAST_MENSAGEM_SUCESSO', trim($_POST['paybras_mensagem_sucesso']));
						}
						
						
						if (!empty($_POST['paybras_token']))
						{
							Configuration::updateValue('PAYBRAST_TOKEN', trim($_POST['paybras_token']));
						}
						
						if (!empty($_POST['paybras_publickey']))
						{
							Configuration::updateValue('PAYBRAST_PUBLICKEY', trim($_POST['paybras_publickey']));
						}
						
						if (!empty($_POST['paybras_idcomercio']))
						{
							Configuration::updateValue('PAYBRAST_IDCOMERCIO', trim($_POST['paybras_idcomercio']));
						}

						if (!empty($_POST['paybras_mensagem_em_analise']))
						{
							Configuration::updateValue('PAYBRAST_MENSAGEM_EM_ANALISE', $_POST['paybras_mensagem_em_analise']);
						}
						
						if (!empty($_POST['paybras_sandbox']))
						{
							Configuration::updateValue('PAYBRAST_SANDBOX', $_POST['paybras_sandbox']);
						}
						
						if (!empty($_POST['paybras_mensagem_aprovado']))
						{
							Configuration::updateValue('PAYBRAST_MENSAGEM_APROVADO', $_POST['paybras_mensagem_aprovado']);
						}
						
						
						if (!empty($_POST['paybras_status1']))
						{
							Configuration::updateValue('PAYBRAST_STATUS1', $_POST['paybras_status1']);
						}
						if (!empty($_POST['paybras_status2']))
						{
							Configuration::updateValue('PAYBRAST_STATUS2', $_POST['paybras_status2']);
						}
						if (!empty($_POST['paybras_status3']))
						{
							Configuration::updateValue('PAYBRAST_STATUS3', $_POST['paybras_status3']);
						}
						if (!empty($_POST['paybras_status5']))
						{
							Configuration::updateValue('PAYBRAST_STATUS5', $_POST['paybras_status5']);
						}
						
					$this->displayConf();
				}
				else $this->displayErrors();
		}
		elseif (isset($_POST['submitpaybras_Btn']))
		{
			Configuration::updateValue('PAYBRAST_BTN', 	$_POST['btn_pg']);
			$this->displayConf();
		}
		

		$this->displayPaybrasT();
		$this->displayFormSettingsPaybrasT();
		
		return $this->_html;
	}
	
	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />
			'.$this->l('Configurações do módulo atualizadas com sucesso!').'
		</div>';
	}
	
	public function displayErrors()
	{
		$nbErrors = sizeof($this->_postErrors);
		$this->_html .= '
		<div class="alert error">
			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
			<ol>';
		foreach ($this->_postErrors AS $error)
			$this->_html .= '<li>'.$error.'</li>';
		$this->_html .= '
			</ol>
		</div>';
	}

	public function displayPaybrasT()
	{
		$this->_html .= '
		<img src="../modules/paybrast/img/paybrast.jpg" style="float:left; margin-right:15px;" />
		<b>'.$this->l('Este módulo permite aceitar pagamentos via Paybrás com TEF.').'</b><br /><br />
		'.$this->l('Se o cliente escolher o módulo de pagamento, a conta do Paybrás sera automaticamente creditado.').'<br />
		'.$this->l('É obrigatório que todas as configurações sejam preenchidas para que o módulo funcione adequadamente.').'
		<br /><br /><br />';
	}

	public function displayFormSettingsPaybrasT()
	{
		$conf = Configuration::getMultiple
		(array(
			'PAYBRAST_EMAIL',
			'PAYBRAST_TOKEN',
			'PAYBRAST_MENSAGEM_PAGAMENTO',
			'PAYBRAST_STATUS1',
			'PAYBRAST_STATUS2',
			'PAYBRAST_STATUS3',
			'PAYBRAST_STATUS5',
			'PAYBRAST_REDIRECIONA',
			'PAYBRAST_SANDBOX',
			'PAYBRAST_MENSAGEM_SUCESSO',
			'PAYBRAST_TEMPLATE'
			
			  )
		);
		
		$email	= array_key_exists('paybras_email', $_POST) ? $_POST['paybras_email'] : (array_key_exists('PAYBRAST_EMAIL', $conf) ? $conf['PAYBRAST_EMAIL'] : '');
		
		$template	= array_key_exists('paybras_template', $_POST) ? $_POST['paybras_template'] : (array_key_exists('PAYBRAST_TEMPLATE', $conf) ? $conf['PAYBRAST_TEMPLATE'] : '');
		
		$sucesso	= array_key_exists('paybras_mensagem_sucesso', $_POST) ? $_POST['paybras_mensagem_sucesso'] : (array_key_exists('PAYBRAST_MENSAGEM_SUCESSO', $conf) ? $conf['PAYBRAST_MENSAGEM_SUCESSO'] : '');
		
		$sandbox	= array_key_exists('paybras_sandbox', $_POST) ? $_POST['paybras_sandbox'] : (array_key_exists('PAYBRAST_SANDBOX', $conf) ? $conf['PAYBRAST_SANDBOX'] : '');
		
		$mensagem_pagamento	= array_key_exists('paybras_mensagem_pagamento', $_POST) ? $_POST['paybras_mensagem_pagamento'] : (array_key_exists('PAYBRAST_MENSAGEM_PAGAMENTO', $conf) ? $conf['PAYBRAST_MENSAGEM_PAGAMENTO'] : '');
		
		$redireciona	= array_key_exists('paybras_redireciona', $_POST) ? $_POST['paybras_redireciona'] : (array_key_exists('PAYBRAST_REDIRECIONA', $conf) ? $conf['PAYBRAST_REDIRECIONA'] : '');
		
		$token			= array_key_exists('paybras_token', $_POST) ? $_POST['paybras_token'] : (array_key_exists('PAYBRAST_TOKEN', $conf) ? $conf['PAYBRAST_TOKEN'] : '');
		
		
		$status1=array_key_exists('paybras_status1', $_POST) ? $_POST['paybras_status1'] : (array_key_exists('PAYBRAST_STATUS1', $conf) ? $conf['PAYBRAST_STATUS1'] : '');
		
		$status2=array_key_exists('paybras_status2', $_POST) ? $_POST['paybras_status2'] : (array_key_exists('PAYBRAST_STATUS2', $conf) ? $conf['PAYBRAST_STATUS2'] : '');
		
		$status3=array_key_exists('paybras_status3', $_POST) ? $_POST['paybras_status3'] : (array_key_exists('PAYBRAST_STATUS3', $conf) ? $conf['PAYBRAST_STATUS3'] : '');
		
		
		$status5=array_key_exists('paybras_status5', $_POST) ? $_POST['paybras_status5'] : (array_key_exists('PAYBRAST_STATUS5', $conf) ? $conf['PAYBRAST_STATUS5'] : '');

		 
		
		 
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
		<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Configurações').'</legend>
			<label>'.$this->l('E-mail da sua conta Paybrás').':</label>
			<div class="margin-form"><input type="text" size="33" name="paybras_email" value="'.htmlentities($email, ENT_COMPAT, 'UTF-8').'" /></div>
			<br />
			
			
			
			<label>API LOGIN</label>
			<div class="margin-form"><input type="text" size="60" name="paybras_token" value="'.$token.'" /></div>
			<br />
			
			
			<label>'.$this->l('Template').':</label>
			<div class="margin-form">'.$this->getCombo('paybras_template', array(1=>'Padrão (com logos dos bancos)', 2=>'Formulário simples'), $template).'</div>
			<br />
			
			
			<h1>Modo de Operação</h1>
			<P>Você pode testar este módulo em modo SANDBOX caso tenha uma conta de desenvolvedor junto à Paybrás. Caso deseje ativar as vendas em sua loja, escolha a opção PRODUÇÃO.</P>
			
			'.$this->selectOpcoes('paybras_sandbox', array(1=>'Produção', 2=>'Sandbox'), $sandbox).'
<br />
			
			<h1>Finalização do pedido</h1>
			<P>Informe se deseja que o comprador seja redirecionado automaticamente para a tela de pagamento do banco ou se deverá ser exibido um botão e o link para que ele possa clicar e efetuar o pagamento.</P>
			
			'.$this->selectOpcoes('paybras_redireciona', array(1=>'Redirecionar', 2=>'Exibir Link'), $redireciona).'
<br />
			<h1>Status dos Pedidos</h1>
			<P>Selecione abaixo os status que devem ser assumidos nas compras de acordo com o estado do pagamento. Caso queira criar mais status em sua loja, acessoe o menu COMPRAS e escolha a opção STATUS.</P>
			
			
			<label>Aguardando Pagamento</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status1', $status1).'</div>
			<br />
			
			<label>Pagamento Confirmado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status2', $status2).'</div>
			<br />
			
			<label>Cancelado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status3', $status3).'</div>
			<br />
			
			
			<label>Devolvido</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status5', $status5).'</div>
			<br />
			
			<label>Mensagem para o pagamento </label>
			<div class="margin-form"><textarea name="paybras_mensagem_pagamento" cols="80" rows="5">'.$mensagem_pagamento.'</textarea></div>
			<br />
			
			<label>Mensagem para o pagamento concluído </label>
			<div class="margin-form"><textarea name="paybras_mensagem_sucesso" cols="80" rows="5">'.$sucesso.'</textarea></div>
			<br />
			
			<center><input type="submit" name="submitPaybras" value="'.$this->l('Atualizar').'" class="button" /></center>
		</fieldset>
		</form>';
		
		
	}

   
	public function hookPayment($params)
	{
		
		global $smarty;
		$smarty->assign(array(
			
			'imgBtn' => "img/bancos.png",
			'this_path' => $this->_path, 'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
			'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,
			'UTF-8') . __PS_BASE_URI__ . 'modules/' . $this->name . '/'));
			
			
			
		return $this->display(__file__, 'payment.tpl');
		
	}
	public function xml2array($contents, $get_attributes=1, $priority = 'tag') 
	{ 
    if(!$contents) return array(); 

    if(!function_exists('xml_parser_create')) { 
     
        return array(); 
    } 

    $parser = xml_parser_create(''); 
    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0); 
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1); 
    xml_parse_into_struct($parser, trim($contents), $xml_values); 
    xml_parser_free($parser); 

    if(!$xml_values) return;

    $xml_array = array(); 
    $parents = array(); 
    $opened_tags = array(); 
    $arr = array(); 

    $current = &$xml_array;

    $repeated_tag_index = array();
    foreach($xml_values as $data) { 
        unset($attributes,$value);

        extract($data);
		
        $result = array(); 
        $attributes_data = array(); 
         
        if(isset($value)) { 
            if($priority == 'tag') $result = $value; 
            else $result['value'] = $value; 
        } 

        if(isset($attributes) and $get_attributes) { 
            foreach($attributes as $attr => $val) { 
                if($priority == 'tag') $attributes_data[$attr] = $val; 
                else $result['attr'][$attr] = $val; 
            } 
        } 

        if($type == "open") {
            $parent[$level-1] = &$current; 
            if(!is_array($current) or (!in_array($tag, array_keys($current)))) {
                $current[$tag] = $result; 
                if($attributes_data) $current[$tag. '_attr'] = $attributes_data; 
                $repeated_tag_index[$tag.'_'.$level] = 1; 

                $current = &$current[$tag]; 

            } else {

                if(isset($current[$tag][0])) {
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result; 
                    $repeated_tag_index[$tag.'_'.$level]++; 
                } else {
                    $current[$tag] = array($current[$tag],$result);
                    $repeated_tag_index[$tag.'_'.$level] = 2; 
                     
                    if(isset($current[$tag.'_attr'])) {  
                        $current[$tag]['0_attr'] = $current[$tag.'_attr']; 
                        unset($current[$tag.'_attr']); 
                    } 

                } 
                $last_item_index = $repeated_tag_index[$tag.'_'.$level]-1; 
                $current = &$current[$tag][$last_item_index]; 
            } 

        } elseif($type == "complete") { 
            if(!isset($current[$tag])) { 
                $current[$tag] = $result; 
                $repeated_tag_index[$tag.'_'.$level] = 1; 
                if($priority == 'tag' and $attributes_data) $current[$tag. '_attr'] = $attributes_data; 

            } else { 
                if(isset($current[$tag][0]) and is_array($current[$tag])) {
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result; 
                     
                    if($priority == 'tag' and $get_attributes and $attributes_data) { 
                        $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data; 
                    } 
                    $repeated_tag_index[$tag.'_'.$level]++; 

                } else { 
                    $current[$tag] = array($current[$tag],$result);
                    $repeated_tag_index[$tag.'_'.$level] = 1; 
                    if($priority == 'tag' and $get_attributes) { 
                        if(isset($current[$tag.'_attr'])) { 
                             
                            $current[$tag]['0_attr'] = $current[$tag.'_attr']; 
                            unset($current[$tag.'_attr']); 
                        } 
                         
                        if($attributes_data) { 
                            $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data; 
                        } 
                    } 
                    $repeated_tag_index[$tag.'_'.$level]++; 
                } 
            } 

        } elseif($type == 'close') { 
            $current = &$parent[$level-1]; 
        } 
    } 
     
    return($xml_array); 
} 
	
	public function hookPaymentReturn($params)
    {
        global $smarty;
		
		$referencia=$params['objOrder']->id;
		$url_boleto="http://".$_SERVER['HTTP_HOST']."/tef.php?id=".$_GET['transacao'];
		
		switch($_GET['res'])
		{
			case 1:
				$titulo="O seguinte erro ocorreu:";
				$mensagem=urldecode($_GET['msg']);
			break;
			
			case 2:
				$titulo="Pedido concluído com sucesso!";
				switch($_GET['banco'])
				{
					case 'tef_bb': $banco='bb'; break;
					case 'tef_itau': $banco='itau'; break;
					case 'tef_bradesco': $banco='bradesco'; break;
					default: exit; break;
				}
				
				$mensagem=Configuration::get('PAYBRAST_MENSAGEM_PAGAMENTO').'<BR /><BR /><a href="'.$url_boleto.'" target="_blank"><img src="'.Tools::getHttpHost(true).__PS_BASE_URI__.'modules/paybrast/img/'.$banco.'_concluir.png" /></a><BR /><BR /><B>Link direto para o pagamento (você será redirecionado para seu home banking):</B> '.$url_boleto;
				
			
			break;
			
			
			case 5:
			
				$titulo="Um erro desconhecido ocorreu";
				$mensagem="Um erro desconhecido ocorreu e seu pedido foi cancelado. Por favor, efetue um novo pedido, verificando atentamente a todos os seus dados. Caso não seja a primeira vez que está recebendo esta mensagem, por favor, entre em contato conosco através do e-mail ".Configuration::get('PAYBRAST_EMAIL').' e nos informe o ocorrido.<BR><BR>Desculpe-nos pelo inconveniente.<BR><BR>';
			break;
			
			case 7: $mensagem=Configuration::get('PAYBRAST_MENSAGEM_SUCESSO');break;
		}
		
		
		$smarty->assign(array(
			'status' 		=> 'ok', 
			'id_order' 		=> $params['objOrder']->id,
			'secure_key' 	=> $params['objOrder']->secure_key,
			'id_module' 	=> $this->id,
			'url_loja'		=> __PS_BASE_URI__,
			'titulo'		=> $titulo,
			'mensagem'		=> $mensagem
		));
		
		
			
		return $this->display(__file__, 'payment_return.tpl');
    }
	
	
	public function parcelar($valorTotal, $taxa, $nParcelas)
	{
		$taxa = $taxa/100;
		$cadaParcela = ($valorTotal*$taxa)/(1-(1/pow(1+$taxa, $nParcelas)));
		return round($cadaParcela, 2);
	}
    
        function hookHome($params)
	{
    	include(dirname(__FILE__).'/includes/retorno.php');
    }
    
        function getStatus($param)
    {
    	global $cookie;
    		
    		$sql_status = Db::getInstance()->Execute
		('
			SELECT `name`
			FROM `'._DB_PREFIX_.'order_state_lang`
			WHERE `id_order_state` = '.$param.'
			AND `id_lang` = '.$cookie->id_lang.'
			
		');
		
		return mysql_result($sql_status, 0);
    }
	
	public function getUrlByMyOrder($myOrder)
	{

		$module				= Module::getInstanceByName($myOrder->module);			
		$pagina_qstring		= __PS_BASE_URI__."order-confirmation.php?id_cart="
							  .$myOrder->id_cart."&id_module=".$module->id."&id_order="
							  .$myOrder->id."&key=".$myOrder->secure_key;			
		
		if	(	$_SERVER['HTTPS']	!=	"on"	)
		$protocolo			=	"http";
		
		else
		$protocolo			=	"https";
		
		$retorno 			= $protocolo . "://" . $_SERVER['SERVER_NAME'] . $pagina_qstring;	
				
		return $retorno;

	}
    
	public function hookHeader($params)
	{

		if(@Context::getContext()->controller->page_name=='module-paybrast-pagar')
		{
			$this->context->controller->addJS('https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/jquery.maskedinput-1.2.1.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/jquery.maskedinput.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/validacao.js', 'all');
			$this->context->controller->addCSS(($this->_path).'css/estilos.css', 'all');
		}
	}
	
}
?>