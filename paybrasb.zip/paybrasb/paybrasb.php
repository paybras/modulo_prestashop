<?php
/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
class PaybrasB extends PaymentModule
{
	private $_html 			= '';
    private $_postErrors 	= array();
    public $currencies;
	private $status;
		
	public function __construct()
    {
        $this->name 			= 'paybrasb';
        $this->tab 				= 'payments_gateways';
        $this->version 			= '1.0';
		$this->author			= "www.consultoriadaweb.com.br";
        $this->currencies 		= true;
        $this->currencies_mode 	= 'radio';
	
		
        parent::__construct();

        $this->page 			= basename(__file__, '.php');
        $this->displayName 		= $this->l('Paybrás - Boleto Bancário');
        $this->description 		= $this->l('Permite receber pagamentos com Boleto Bancário através do gateway Paybrás');
		$this->confirmUninstall = $this->l('Tem certeza de que pretende eliminar os seus dados?');
		$this->textshowemail 	= $this->l('Você receberá por mensagens por e-mail informando a cadaatualização da sua compra.');
	}
	
	public function install()
	{
		
		
        $this->create_paybras_transacoes_table();

		if(!$email=Configuration::get('PAYBRASB_EMAIL'))
			$email='paybras@seudominio.com.br';
		

		if(!$token=Configuration::get('PAYBRASB_TOKEN'))
			$token='';
			
		if(!$status1=Configuration::get('PAYBRASB_STATUS1'))
		$status1='';
			
		if(!$status2=Configuration::get('PAYBRASB_STATUS2'))
			$status2='';
			
		if(!$status3=Configuration::get('PAYBRASB_STATUS3'))
			$status3='';

		if 
		(
			!parent::install() 
		OR 	!Configuration::updateValue('PAYBRASB_EMAIL', $email)
		OR 	!Configuration::updateValue('PAYBRASB_TOKEN', $token)
		OR 	!Configuration::updateValue('PAYBRASB_STATUS1', 	  $status1)
		OR 	!Configuration::updateValue('PAYBRASB_STATUS2', 	  $status2)
		OR 	!Configuration::updateValue('PAYBRASB_STATUS3', 	  $status3)
		OR 	!Configuration::updateValue('PAYBRASB_BTN', 	  0)  
		OR 	!Configuration::updateValue('PAYBRASB_MENSAGEM_PAGAMENTO',   'Seu pedido foi concluído com sucesso! Para finalizar sua compra, imprima o boleto abaixo e efetue seu pagamento:')

		OR 	!$this->registerHook('payment') 
		OR 	!$this->registerHook('paymentReturn')
		OR 	!$this->registerHook('header')
		)
			return false;
			
		return true;
	}


    public function create_paybras_transacoes_table()
    {
		try {
    
			@Db::getInstance()->Execute('ALTER TABLE `'._DB_PREFIX_.'orders` ADD `id_transacao_paybras` VARCHAR(36) NULL ;');
			
			} catch (Exception $e) {}

		try {
    
			@Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'transacoes_paybras` (
			  `id_order` int(11) NOT NULL,
			  `meio_pagamento` char(1) NOT NULL,
			  `ip` varchar(15) NOT NULL,
			  `nome` varchar(30) NOT NULL,
			  `bandeira` varchar(20) NOT NULL,
			  `bin` varchar(20) NOT NULL,
			  `telefone` varchar(15) NOT NULL,
			  `cpf` varchar(14) NOT NULL,
			  `id_transacao` int(11) NOT NULL,
			  `codigo_nao_autorizado` int(11) NOT NULL,
			  `recuperada` int(11) NOT NULL,
			  `parcelas` int(11) NOT NULL,
			  PRIMARY KEY (`id_order`)
			) ;
			');
		} catch (Exception $e) { }

    }

	public function uninstall()
	{
		if 
		(	!parent::uninstall()
		) 
			return false;
		
		return true;
	}
	
	private function setStatus()
	{
		global $cookie;
		$id_lang = $cookie->id_lang;

		$sql="SELECT name, id_order_state FROM "._DB_PREFIX_."order_state_lang WHERE id_lang=".$id_lang."";
		
		
		$this->status=Db::getInstance()->ExecuteS($sql);
	}
	
	private function getComboStatus($nome, $selecionado=false)
	{
		if(!$this->status)
		{
			
			$this->setStatus();
			
		}
		$combo='<select name="'.$nome.'" id="'.$nome.'">';
		
		for($i=0; $i < count($this->status); $i++)
		{
			if($this->status[$i]['id_order_state']!=$selecionado)
				$combo .='<option value="'.$this->status[$i]['id_order_state'].'" >'.$this->status[$i]['name'].'</option>>';
			else
				$combo .='<option value="'.$this->status[$i]['id_order_state'].'" selected="selected">'.$this->status[$i]['name'].'</option>>';
			
		}
		
		$combo .="</select>";
		
		
		return ($combo);
		
		
	}

	public function getContent()
	{
		/*
			Essa função é responsável por salvar os dados da configuração
		*/
		$this->_html = '<h2>Paybrás - Boleto Bancário</h2>';
		
		if (isset($_POST['submitPaybras']))
		{
			if (empty($_POST['paybras_email'])) $this->_postErrors[] = $this->l('E-mail da conta Paybrás');
			elseif (!Validate::isEmail($_POST['paybras_email'])) $this->_postErrors[] = $this->l('Digite um e-mail válido!');
			
				if (!sizeof($this->_postErrors)) 
				{
						Configuration::updateValue('PAYBRASB_EMAIL', $_POST['paybras_email']);
						
						if (!empty($_POST['paybras_contaid']))
						{
							Configuration::updateValue('PAYBRASB_CONTAID', trim($_POST['paybras_contaid']));
						}
						
						if (!empty($_POST['paybras_apikey']))
						{
							Configuration::updateValue('PAYBRASB_APIKEY', trim($_POST['paybras_apikey']));
						}
						
						if (!empty($_POST['paybras_token']))
						{
							Configuration::updateValue('PAYBRASB_TOKEN', trim($_POST['paybras_token']));
						}
						
						if (!empty($_POST['paybras_publickey']))
						{
							Configuration::updateValue('PAYBRASB_PUBLICKEY', trim($_POST['paybras_publickey']));
						}
						
						if (!empty($_POST['paybras_idcomercio']))
						{
							Configuration::updateValue('PAYBRASB_IDCOMERCIO', trim($_POST['paybras_idcomercio']));
						}

						
						
						if (!empty($_POST['paybras_mensagem_em_analise']))
						{
							Configuration::updateValue('PAYBRASB_MENSAGEM_EM_ANALISE', $_POST['paybras_mensagem_em_analise']);
						}
						
						if (!empty($_POST['paybras_mensagem_aprovado']))
						{
							Configuration::updateValue('PAYBRASB_MENSAGEM_APROVADO', $_POST['paybras_mensagem_aprovado']);
						}
						
						if (!empty($_POST['paybras_mensagem_cancelado']))
						{
							Configuration::updateValue('PAYBRASB_MENSAGEM_CANCELADO', $_POST['paybras_mensagem_cancelado']);
						}
						if (!empty($_POST['paybras_status1']))
						{
							Configuration::updateValue('PAYBRASB_STATUS1', $_POST['paybras_status1']);
						}
						if (!empty($_POST['paybras_status2']))
						{
							Configuration::updateValue('PAYBRASB_STATUS2', $_POST['paybras_status2']);
						}
						if (!empty($_POST['paybras_status3']))
						{
							Configuration::updateValue('PAYBRASB_STATUS3', $_POST['paybras_status3']);
						}
						if (!empty($_POST['paybras_status4']))
						{
							Configuration::updateValue('PAYBRASB_STATUS4', $_POST['paybras_status4']);
						}
						
						if (!empty($_POST['mensagem_pagamento']))
						{
							Configuration::updateValue('PAYBRASB_MENSAGEM_PAGAMENTO', $_POST['mensagem_pagamento']);
						}
						
					$this->displayConf();
				}
				else $this->displayErrors();
		}
		elseif (isset($_POST['submitpaybras_Btn']))
		{
			Configuration::updateValue('PAYBRASB_BTN', 	$_POST['btn_pg']);
			$this->displayConf();
		}
		

		$this->displayPaybrasB();
		$this->displayFormSettingsPaybrasB();
		
		return $this->_html;
	}
	
	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />
			'.$this->l('Configurações do módulo atualizadas com sucesso!').'
		</div>';
	}
	
	public function displayErrors()
	{
		$nbErrors = sizeof($this->_postErrors);
		$this->_html .= '
		<div class="alert error">
			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
			<ol>';
		foreach ($this->_postErrors AS $error)
			$this->_html .= '<li>'.$error.'</li>';
		$this->_html .= '
			</ol>
		</div>';
	}

	public function displayPaybrasB()
	{
		$this->_html .= '
		<img src="../modules/paybrasb/img/paybrasb.jpg" style="float:left; margin-right:15px;" />
		<b>'.$this->l('Este módulo permite aceitar pagamentos via Paybrás com Boleto Bancário.').'</b><br /><br />
		'.$this->l('Se o cliente escolher o módulo de pagamento, a conta do Paybrás sera automaticamente creditado.').'<br />
		'.$this->l('É obrigatório que todas as configurações sejam preenchidas para que o módulo funcione adequadamente.').'
		<br /><br /><br />';
	}

	public function displayFormSettingsPaybrasB()
	{
		$conf = Configuration::getMultiple
		(array(
			'PAYBRASB_EMAIL',
			'PAYBRASB_TOKEN',
			'PAYBRASB_STATUS1',
			'PAYBRASB_STATUS2',
			'PAYBRASB_STATUS3',
			'PAYBRASB_STATUS4',
			'PAYBRASB_MENSAGEM_PAGAMENTO'
			
			  )
		);
		
		$email	= array_key_exists('paybras_email', $_POST) ? $_POST['paybras_email'] : (array_key_exists('PAYBRASB_EMAIL', $conf) ? $conf['PAYBRASB_EMAIL'] : '');
		
		$token			= array_key_exists('paybras_token', $_POST) ? $_POST['paybras_token'] : (array_key_exists('PAYBRASB_TOKEN', $conf) ? $conf['PAYBRASB_TOKEN'] : '');
		
		$mensagem_aprovado=array_key_exists('paybras_mensagem_aprovado', $_POST) ? $_POST['paybras_mensagem_aprovado'] : (array_key_exists('PAYBRASB_MENSAGEM_APROVADO', $conf) ? $conf['PAYBRASB_MENSAGEM_APROVADO'] : '');
		
		$status1=array_key_exists('paybras_status1', $_POST) ? $_POST['paybras_status1'] : (array_key_exists('PAYBRASB_STATUS1', $conf) ? $conf['PAYBRASB_STATUS1'] : '');
		
		$status2=array_key_exists('paybras_status2', $_POST) ? $_POST['paybras_status2'] : (array_key_exists('PAYBRASB_STATUS2', $conf) ? $conf['PAYBRASB_STATUS2'] : '');
		
		$status3=array_key_exists('paybras_status3', $_POST) ? $_POST['paybras_status3'] : (array_key_exists('PAYBRASB_STATUS3', $conf) ? $conf['PAYBRASB_STATUS3'] : '');
		
		$status4=array_key_exists('paybras_status4', $_POST) ? $_POST['paybras_status4'] : (array_key_exists('PAYBRASB_STATUS4', $conf) ? $conf['PAYBRASB_STATUS4'] : '');
		
		$mensagem_pagamento=array_key_exists('mensagem_pagamento', $_POST) ? $_POST['mensagem_pagamento'] : (array_key_exists('PAYBRASB_MENSAGEM_PAGAMENTO', $conf) ? $conf['PAYBRASB_MENSAGEM_PAGAMENTO'] : '');

		 
		
		 
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
		<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Configurações').'</legend>
			<label>'.$this->l('E-mail da sua conta Paybrás').':</label>
			<div class="margin-form"><input type="text" size="33" name="paybras_email" value="'.htmlentities($email, ENT_COMPAT, 'UTF-8').'" /></div>
			<br />
			
			
			<label>TOKEN</label>
			<div class="margin-form"><input type="text" size="60" name="paybras_token" value="'.$token.'" /></div>
			<br />

			<h1>Status dos Pedidos</h1>
			<P>Selecione abaixo os status que devem ser assumidos nas compras de acordo com o estado do pagamento. Caso queira criar mais status em sua loja, acessoe o menu COMPRAS e escolha a opção STATUS.</P>
			
			
			<label>Aguardando Pagamento</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status1', $status1).'</div>
			<br />
			
			<label>Pagamento Confirmado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status2', $status2).'</div>
			<br />
			
			<label>Cancelado</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status3', $status3).'</div>
			<br />
			
			<label>Devolvido</label>
			<div class="margin-form">'.$this->getComboStatus('paybras_status4', $status4).'</div>
			<br />
						
			
			<label>Mensagem para o pagamento do boleto</label>
			<div class="margin-form"><textarea name="mensagem_pagamento" cols="80" rows="5">'.$mensagem_pagamento.'</textarea></div>
			<br />
			
			
			
			<center><input type="submit" name="submitPaybras" value="'.$this->l('Atualizar').'" class="button" /></center>
		</fieldset>
		</form>';
		
		
	}

    public function execPayment($cart)
    {
    }
	
	public function hookPayment($params)
	{
		
		global $smarty;
		$smarty->assign(array(
			
			'imgBtn' => "img/boleto.png",
			'this_path' => $this->_path, 
			'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
			'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,
			'UTF-8') . __PS_BASE_URI__ . 'modules/paybrasb/'));
		
			
		return $this->display(__file__, 'payment.tpl');
		
	}
	public function xml2array($contents, $get_attributes=1, $priority = 'tag') 
	{ 
    if(!$contents) return array(); 

    if(!function_exists('xml_parser_create')) { 
     
        return array(); 
    } 

    $parser = xml_parser_create(''); 
    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0); 
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1); 
    xml_parse_into_struct($parser, trim($contents), $xml_values); 
    xml_parser_free($parser); 

    if(!$xml_values) return;

    $xml_array = array(); 
    $parents = array(); 
    $opened_tags = array(); 
    $arr = array(); 

    $current = &$xml_array;

    $repeated_tag_index = array();
    foreach($xml_values as $data) { 
        unset($attributes,$value);

        extract($data);
		
        $result = array(); 
        $attributes_data = array(); 
         
        if(isset($value)) { 
            if($priority == 'tag') $result = $value; 
            else $result['value'] = $value; 
        } 

        if(isset($attributes) and $get_attributes) { 
            foreach($attributes as $attr => $val) { 
                if($priority == 'tag') $attributes_data[$attr] = $val; 
                else $result['attr'][$attr] = $val; 
            } 
        } 

        if($type == "open") {
            $parent[$level-1] = &$current; 
            if(!is_array($current) or (!in_array($tag, array_keys($current)))) {
                $current[$tag] = $result; 
                if($attributes_data) $current[$tag. '_attr'] = $attributes_data; 
                $repeated_tag_index[$tag.'_'.$level] = 1; 

                $current = &$current[$tag]; 

            } else {

                if(isset($current[$tag][0])) {
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result; 
                    $repeated_tag_index[$tag.'_'.$level]++; 
                } else {
                    $current[$tag] = array($current[$tag],$result);
                    $repeated_tag_index[$tag.'_'.$level] = 2; 
                     
                    if(isset($current[$tag.'_attr'])) {  
                        $current[$tag]['0_attr'] = $current[$tag.'_attr']; 
                        unset($current[$tag.'_attr']); 
                    } 

                } 
                $last_item_index = $repeated_tag_index[$tag.'_'.$level]-1; 
                $current = &$current[$tag][$last_item_index]; 
            } 

        } elseif($type == "complete") { 
            if(!isset($current[$tag])) { 
                $current[$tag] = $result; 
                $repeated_tag_index[$tag.'_'.$level] = 1; 
                if($priority == 'tag' and $attributes_data) $current[$tag. '_attr'] = $attributes_data; 

            } else { 
                if(isset($current[$tag][0]) and is_array($current[$tag])) {
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result; 
                     
                    if($priority == 'tag' and $get_attributes and $attributes_data) { 
                        $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data; 
                    } 
                    $repeated_tag_index[$tag.'_'.$level]++; 

                } else { 
                    $current[$tag] = array($current[$tag],$result);
                    $repeated_tag_index[$tag.'_'.$level] = 1; 
                    if($priority == 'tag' and $get_attributes) { 
                        if(isset($current[$tag.'_attr'])) { 
                             
                            $current[$tag]['0_attr'] = $current[$tag.'_attr']; 
                            unset($current[$tag.'_attr']); 
                        } 
                         
                        if($attributes_data) { 
                            $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data; 
                        } 
                    } 
                    $repeated_tag_index[$tag.'_'.$level]++; 
                } 
            } 

        } elseif($type == 'close') { 
            $current = &$parent[$level-1]; 
        } 
    } 
     
    return($xml_array); 
} 
	
	public function hookPaymentReturn($params)
    {
        global $smarty;
		
		$referencia=$params['objOrder']->id;
		$url_boleto="http://".$_SERVER['HTTP_HOST']."/boleto.php?id=".$_GET['transacao'];
		
		switch($_GET['res'])
		{
			case 1:
				$titulo="O seguinte erro ocorreu:";
				$mensagem=urldecode($_GET['msg']);
			break;
			
			case 2:
				$titulo="Pedido concluído com sucesso!";
				
				$mensagem=Configuration::get('PAYBRASB_MENSAGEM_PAGAMENTO').'<BR /><BR /><a href="'.$url_boleto.'" target="_blank"><img src="'.Tools::getHttpHost(true).__PS_BASE_URI__.'modules/paybrasb/img/botao_imprimir_boleto.png" /></a><BR />Link direto para o boleto: '.$url_boleto;
				
			
			break;
			
			
			case 5:
			
				$titulo="Um erro desconhecido ocorreu";
				$mensagem="Um erro desconhecido ocorreu e seu pedido foi cancelado. Por favor, efetue um novo pedido, verificando atentamente a todos os seus dados. Caso não seja a primeira vez que está recebendo esta mensagem, por favor, entre em contato conosco através do e-mail ".Configuration::get('PAYBRASB_EMAIL').' e nos informe o ocorrido.<BR><BR>Desculpe-nos pelo inconveniente.<BR><BR>';
			break;
		}
		
		
		$smarty->assign(array(
			'status' 		=> 'ok', 
			'id_order' 		=> $params['objOrder']->id,
			'secure_key' 	=> $params['objOrder']->secure_key,
			'id_module' 	=> $this->id,
			'url_loja'		=> __PS_BASE_URI__,
			'titulo'		=> $titulo,
			'mensagem'		=> $mensagem
		));
		
		return $this->display(__file__, 'payment_return.tpl');
    }
	
	
	public function parcelar($valorTotal, $taxa, $nParcelas)
	{
		$taxa = $taxa/100;
		$cadaParcela = ($valorTotal*$taxa)/(1-(1/pow(1+$taxa, $nParcelas)));
		return round($cadaParcela, 2);
	}
    

    
    function getStatus($param)
    {
    	global $cookie;
    		
    		$sql_status = Db::getInstance()->Execute
		('
			SELECT `name`
			FROM `'._DB_PREFIX_.'order_state_lang`
			WHERE `id_order_state` = '.$param.'
			AND `id_lang` = '.$cookie->id_lang.'
			
		');
		
		return mysql_result($sql_status, 0);
    }
	
	public function getUrlByMyOrder($myOrder)
	{

		$module				= Module::getInstanceByName($myOrder->module);			
		$pagina_qstring		= __PS_BASE_URI__."order-confirmation.php?id_cart="
							  .$myOrder->id_cart."&id_module=".$module->id."&id_order="
							  .$myOrder->id."&key=".$myOrder->secure_key;			
		
		if	(	$_SERVER['HTTPS']	!=	"on"	)
		$protocolo			=	"http";
		
		else
		$protocolo			=	"https";
		
		$retorno 			= $protocolo . "://" . $_SERVER['SERVER_NAME'] . $pagina_qstring;	
				
		return $retorno;

	}
	
	public function hookHeader($params)
	{
		if(@Context::getContext()->controller->page_name=='module-paybrasb-pagar')
		{
			$this->context->controller->addJS('https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/jquery.maskedinput.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/messi.min.js', 'all');
			$this->context->controller->addJS(($this->_path).'js/validacao.js', 'all');
			$this->context->controller->addCSS(($this->_path).'css/estilos.css', 'all');
		}
	}
    
}
?>