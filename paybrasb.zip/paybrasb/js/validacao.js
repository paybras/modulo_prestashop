/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
 function is_int(value){
  if((parseInt(value)) && !isNaN(value)){
      return true;
  } else {
      return false;
  }
}

function verificarCPF(cpf)
{
	c=cpf.substr(0,3) +""+cpf.substr(4,3)+""+cpf.substr(8,3)+""+cpf.substr(12,2);
		if (c.length != 11 || c == "00000000000" || c == "11111111111" || c == "22222222222" || c == "33333333333" || c == "44444444444" || c == "55555555555" || c == "66666666666" || c == "77777777777" || c == "88888888888" || c == "99999999999")
		{
			alert('CPF Inválido!');
			return false;
		}
		
		var i;
		s = c;
		var c = s.substr(0,9);
		var dv = s.substr(9,2);
		var d1 = 0;
		var v = false;

		for (i = 0; i < 9; i++)
		{
			d1 += c.charAt(i)*(10-i);
		}
		if (d1 == 0)
		{
			alert("CPF Inválido!");
			v = true;
			
			return false;
		}
		d1 = 11 - (d1 % 11);
		
		if (d1 > 9) d1 = 0;
		
		if (dv.charAt(0) != d1)
		{
			alert("CPF Inválido!");
			v = true;
			return false;
		}
	 
		d1 *= 2;
		for (i = 0; i < 9; i++)
		{
			d1 += c.charAt(i)*(11-i);
		}
		
		d1 = 11 - (d1 % 11);
		
		if (d1 > 9) d1 = 0;
		
		if (dv.charAt(1) != d1)
		{
			alert("CPF Inválido");
			v = true;
			
			return false;
		}
		if (!v) 
		{
			return true;
		}
		
		return false;
	}

	
	function pagar()
	{
		
		if(document.getElementById('cpf').value=="")
		{
			alert('Por favor, informe o CPF do pagador do boleto');
			return false;
		}
		
		if(verificarCPF(document.getElementById('cpf').value)==false)
		{
			return false;
		}
		
		if(document.getElementById('telefone').value.length < 12)
		{
			alert('Por favor, informe corretamente o número do telefone');
			return false;
		}
		
		
		
		document.getElementById('div_botao_enviar').style.display="none";
		document.getElementById('carregando').style.display="block";
		
		return true;
		
	}
	
