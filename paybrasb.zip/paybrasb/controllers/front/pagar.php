﻿<?php 
/**
 * @author Andresa
 * @copyright Consultoria da Web
 * @site http://www.consultoriadaweb.com.br
 **/
 
 class PaybrasBPagarModuleFrontController extends ModuleFrontController{
	public function initContent() {
		$mpag = new PaybrasB();
		$this->display_column_left = false;
		$this->ssl = true;
		$this->display_column_right=false;
		parent::initContent();
		
		global $cookie, $smarty,$cart;
			
        $invoiceAddress 	= new Address(intval($cart->id_address_invoice));
        $customerPag 		= new Customer(intval($cart->id_customer));
        $currencies 		= Currency::getCurrencies();
        $currencies_used 	= array();
		$currency 			= $mpag->getCurrency();

        $currencies 		= Currency::getCurrencies();		
	
		
        foreach ($currencies as $key => $currency)
            $smarty->assign(array(
                'publickey' => Configuration::get('PAYBRASB_PUBLICKEY'),
                'currency_default' => new Currency(Configuration::get('PS_CURRENCY_DEFAULT')),
                'currencies' => $currencies_used, 
                'imgBtn' => "img/boleto.jpg",

                'currency_default' => new Currency(Configuration::get('PS_CURRENCY_DEFAULT')),
                'currencies' => $currencies_used, 
                'total' => number_format(Tools::convertPrice($cart->getOrderTotal(true, 3), $currency), 2, '.', ''), 
                'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ?
                'https://' : 'http://') . htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT,'UTF-8') . __PS_BASE_URI__ . 'modules/' . $mpag->name . '/'));
			
       $this->setTemplate('payment_execution.tpl');
	   ob_clean();
	}
} ?>